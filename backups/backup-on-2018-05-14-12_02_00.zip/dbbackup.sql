#
# TABLE STRUCTURE FOR: tbl_cargo
#

DROP TABLE IF EXISTS `tbl_cargo`;

CREATE TABLE `tbl_cargo` (
  `id_cargo` int(11) NOT NULL AUTO_INCREMENT,
  `nome_cargo` varchar(100) NOT NULL,
  `comentario_cargo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_cargo`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (1, Analista de Suporte, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (2, Analista de Produção, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (3, Analista de Infraestrutura, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (4, Analista de Sistemas, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (5, Analista de Banco de Dados, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (6, Técnico de Informática, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (7, Trainee, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (8, Estagiário, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (9, Técnico Administrativo, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (10, Gerente, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (11, Gerente de RH, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (12, Gerente de Projeto, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (13, Coordenador(a), );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (14, Diretor(a), );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (15, Analista de Suporte Help Desk, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (16, Servidor Público, );


#
# TABLE STRUCTURE FOR: tbl_cidade
#

DROP TABLE IF EXISTS `tbl_cidade`;

CREATE TABLE `tbl_cidade` (
  `id_cidade` int(11) NOT NULL AUTO_INCREMENT,
  `nome_cidade` varchar(100) NOT NULL,
  `comentario_cidade` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_cidade`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (1, Abaetetuba, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (2, Abel Figueiredo, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (3, Acará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (4, Afuá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (5, Água Azul do Norte, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (6, Alenquer, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (7, Almeirim, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (8, Altamira, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (9, Anajás, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (10, Ananindeua, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (11, Anapu, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (12, Augusto Corrêa, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (13, Aurora do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (14, Aveiro, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (15, Bagre, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (16, Baião, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (17, Bannach, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (18, Barcarena, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (19, Belém, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (20, Belterra, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (21, Benevides, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (22, Bom Jesus do Tocantins, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (23, Bonito, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (24, Bragança, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (25, Brasil Novo, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (26, Brejo Grande do Araguaia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (27, Breu Branco, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (28, Breves, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (29, Bujaru, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (30, Cachoeira do Arari, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (31, Cachoeira do Piriá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (32, Cametá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (33, Canaã dos Carajás, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (34, Capanema, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (35, Capitão Poço, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (36, Castanhal, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (37, Chaves, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (38, Colares, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (39, Conceição do Araguaia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (40, Concórdia do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (41, Cumaru do Norte, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (42, Curionópolis, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (43, Curralinho, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (44, Curuá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (45, Curuçá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (46, Dom Eliseu, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (47, Eldorado do Carajás, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (48, Faro, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (49, Floresta do Araguaia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (50, Garrafão do Norte, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (51, Goianésia do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (52, Gurupá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (53, Igarapé-Açu, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (54, Igarapé-Miri, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (55, Inhangapi, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (56, Ipixuna do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (57, Irituia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (58, Itaituba, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (59, Itupiranga, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (60, Jacareacanga, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (61, Jacundá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (62, Juruti, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (63, Limoeiro do Ajuru, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (64, Mãe do Rio, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (65, Magalhães Barata, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (66, Marabá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (67, Maracanã, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (68, Marapanim, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (69, Marituba, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (70, Medicilândia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (71, Melgaço, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (72, Mocajuba, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (73, Moju, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (74, Mojuí dos Campos, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (75, Monte Alegre, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (76, Muaná, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (77, Nova Esperança do Piriá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (78, Nova Ipixuna, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (79, Nova Timboteua, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (80, Novo Progresso, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (81, Novo Repartimento, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (82, Óbidos, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (83, Oeiras do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (84, Oriximiná, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (85, Ourém, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (86, Ourilândia do Norte, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (87, Pacajá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (88, Palestina do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (89, Paragominas, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (90, Parauapebas, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (91, Pau d`Arco, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (92, Peixe-Boi, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (93, Piçarra, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (94, Placas, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (95, Ponta de Pedras, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (96, Portel, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (97, Porto de Moz, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (98, Prainha, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (99, Primavera, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (100, Quatipuru, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (101, Redenção, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (102, Rio Maria, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (103, Rondon do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (104, Rurópolis, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (105, Salinópolis, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (106, Salvaterra, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (107, Santa Bárbara do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (108, Santa Cruz do Arari, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (109, Santa Izabel do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (110, Santa Luzia do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (111, Santa Maria das Barreiras, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (112, Santa Maria do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (113, Santana do Araguaia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (114, Santarém, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (115, Santarém Novo, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (116, Santo Antônio do Tauá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (117, São Caetano de Odivelas, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (118, São Domingos do Araguaia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (119, São Domingos do Capim, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (120, São Félix do Xingu, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (121, São Francisco do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (122, São Geraldo do Araguaia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (123, São João da Ponta, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (124, São João de Pirabas, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (125, São João do Araguaia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (126, São Miguel do Guamá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (127, São Sebastião da Boa Vista, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (128, Sapucaia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (129, Senador José Porfírio, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (130, Soure, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (131, Tailândia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (132, Terra Alta, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (133, Terra Santa, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (134, Tomé-Açu, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (135, Tracuateua, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (136, Trairão, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (137, Tucumã, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (138, Tucuruí, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (139, Ulianópolis, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (140, Uruará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (141, Vigia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (142, Viseu, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (143, Vitória do Xingu, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (144, Xinguara, NULL);


#
# TABLE STRUCTURE FOR: tbl_contato
#

DROP TABLE IF EXISTS `tbl_contato`;

CREATE TABLE `tbl_contato` (
  `id_contato` int(11) NOT NULL AUTO_INCREMENT,
  `nome_contato` varchar(100) NOT NULL,
  `email_contato` varchar(100) NOT NULL,
  `cargo_contato` varchar(100) DEFAULT NULL,
  `comentario_contato` varchar(100) DEFAULT NULL,
  `id_fornecedor` int(11) NOT NULL,
  PRIMARY KEY (`id_contato`),
  KEY `FK_tbl_contato_tbl_fornecedor` (`id_fornecedor`),
  CONSTRAINT `FK_tbl_contato_tbl_fornecedor` FOREIGN KEY (`id_fornecedor`) REFERENCES `tbl_fornecedor` (`id_fornecedor`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (1, Bárbara, , Central de Atendimento, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (2, Anderson, , Técnico, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (3, Paulo Branco, , Dados, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (4, Valdenildo, , Técnicos Externos, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (5, Fernando, , Técnicos Externos, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (6, Ana Caroline, acsanto@embratel.com.br, Central de Atendimento, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (7, Adamor Martins de Sousa, adamors@embratel.com.br, , , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (8, Jailson Viera Dantas, jailson@embratel.com.br, Unidade Corporativa, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (9, Edilson Ramos Pereira Filho, edramos@embratel.com.br, Gerente Executivo de Vendas, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (10, Domier Ferreira Cavalcante  Junior, domier@embratel.com.br, Gerente de Contas Governo, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (11, Lucineide Costa Conceição, lucost@embratel.com.br, Unidade de Mercado Empresarial, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (12, Margarete Ferreira Barbosa, marbosa@embratel.com.br, Gerência de Acesso e Ativação PA/AP/MA, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (13, Maria Francisca Chihomi Tanaka Owada, tanaka@embratel.com.br, Unidade de Mercado Empresarial, , 1);


#
# TABLE STRUCTURE FOR: tbl_contato_telefone
#

DROP TABLE IF EXISTS `tbl_contato_telefone`;

CREATE TABLE `tbl_contato_telefone` (
  `id_contato` int(11) NOT NULL,
  `id_telefone` int(11) NOT NULL,
  PRIMARY KEY (`id_contato`,`id_telefone`),
  KEY `FK_tbl_contato_telefone_tbl_telefone` (`id_telefone`),
  KEY `FK_tbl_contato_telefone_tbl_contato` (`id_contato`),
  CONSTRAINT `FK_tbl_contato_telefone_tbl_contato` FOREIGN KEY (`id_contato`) REFERENCES `tbl_contato` (`id_contato`),
  CONSTRAINT `FK_tbl_contato_telefone_tbl_telefone` FOREIGN KEY (`id_telefone`) REFERENCES `tbl_telefone` (`id_telefone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (1, 42);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (2, 21);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (2, 22);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (3, 23);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (3, 24);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (4, 25);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (4, 26);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (5, 27);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (5, 28);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (6, 43);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (6, 44);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (7, 45);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (7, 46);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (8, 47);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (8, 48);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (9, 49);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (9, 50);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (10, 53);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (10, 54);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (11, 51);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (11, 52);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (12, 57);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (13, 58);


#
# TABLE STRUCTURE FOR: tbl_expediente
#

DROP TABLE IF EXISTS `tbl_expediente`;

CREATE TABLE `tbl_expediente` (
  `id_expediente` int(11) NOT NULL AUTO_INCREMENT,
  `nome_expediente` varchar(100) NOT NULL,
  `comentario_expediente` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_expediente`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_expediente` (`id_expediente`, `nome_expediente`, `comentario_expediente`) VALUES (1, 8h - 14h, NULL);
INSERT INTO `tbl_expediente` (`id_expediente`, `nome_expediente`, `comentario_expediente`) VALUES (2, 8h - 17h, NULL);
INSERT INTO `tbl_expediente` (`id_expediente`, `nome_expediente`, `comentario_expediente`) VALUES (3, 8h - 18h, NULL);
INSERT INTO `tbl_expediente` (`id_expediente`, `nome_expediente`, `comentario_expediente`) VALUES (4, 24hs, );


#
# TABLE STRUCTURE FOR: tbl_fornecedor
#

DROP TABLE IF EXISTS `tbl_fornecedor`;

CREATE TABLE `tbl_fornecedor` (
  `id_fornecedor` int(11) NOT NULL AUTO_INCREMENT,
  `nome_fornecedor` varchar(100) NOT NULL,
  `website_fornecedor` varchar(100) DEFAULT NULL,
  `email_fornecedor` varchar(100) DEFAULT NULL,
  `endereco_fornecedor` varchar(100) DEFAULT NULL,
  `comentario_fornecedor` varchar(100) DEFAULT NULL,
  `status_fornecedor` tinyint(1) NOT NULL DEFAULT '1',
  `id_servico` int(11) NOT NULL,
  PRIMARY KEY (`id_fornecedor`),
  KEY `FK_tbl_fornecedor_tbl_servico` (`id_servico`),
  CONSTRAINT `FK_tbl_fornecedor_tbl_servico` FOREIGN KEY (`id_servico`) REFERENCES `tbl_servico` (`id_servico`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_fornecedor` (`id_fornecedor`, `nome_fornecedor`, `website_fornecedor`, `email_fornecedor`, `endereco_fornecedor`, `comentario_fornecedor`, `status_fornecedor`, `id_servico`) VALUES (1, Embratel, http://www.embratel.com.br/embratelonline, , , , 1, 1);
INSERT INTO `tbl_fornecedor` (`id_fornecedor`, `nome_fornecedor`, `website_fornecedor`, `email_fornecedor`, `endereco_fornecedor`, `comentario_fornecedor`, `status_fornecedor`, `id_servico`) VALUES (2, PRODEPA, http://www.prodepa.pa.gov.br/, cap@prodepa.pa.gov.br, Av. Agusto Montenegro, s/n, , 1, 1);
INSERT INTO `tbl_fornecedor` (`id_fornecedor`, `nome_fornecedor`, `website_fornecedor`, `email_fornecedor`, `endereco_fornecedor`, `comentario_fornecedor`, `status_fornecedor`, `id_servico`) VALUES (3, Compwire, http://suporte.compwire.com.br:8081/cw/sefapa/, suporte@compwire.com.br, Rua Comendador Roseira, 352  Prado Velho - Curitiba - PR, 0800-600-8030, 1, 3);
INSERT INTO `tbl_fornecedor` (`id_fornecedor`, `nome_fornecedor`, `website_fornecedor`, `email_fornecedor`, `endereco_fornecedor`, `comentario_fornecedor`, `status_fornecedor`, `id_servico`) VALUES (4, VALSPE, http://www.valspe.com.br, , Av. Raja Gabáglia, 3348 - Estoril, Belo Horizonte - MG, 30350-540, 0800-55-6405, 1, 3);
INSERT INTO `tbl_fornecedor` (`id_fornecedor`, `nome_fornecedor`, `website_fornecedor`, `email_fornecedor`, `endereco_fornecedor`, `comentario_fornecedor`, `status_fornecedor`, `id_servico`) VALUES (5, GEMELO, http://nobreak.sefa.pa.gov.br:8080/ScadaBR/login.htm, suporte@gemelo.com.br, Rua Monte Pascal, 64 ​São Paulo- SP, 0800-818-280, 1, 4);


#
# TABLE STRUCTURE FOR: tbl_fornecedor_telefone
#

DROP TABLE IF EXISTS `tbl_fornecedor_telefone`;

CREATE TABLE `tbl_fornecedor_telefone` (
  `id_fornecedor` int(11) NOT NULL,
  `id_telefone` int(11) NOT NULL,
  PRIMARY KEY (`id_fornecedor`,`id_telefone`),
  KEY `FK_tbl_fornecedor_telefone_tbl_telefone` (`id_telefone`),
  KEY `FK_tbl_fornecedor_telefone_tbl_fornecedor` (`id_fornecedor`),
  CONSTRAINT `FK_tbl_fornecedor_telefone_tbl_fornecedor` FOREIGN KEY (`id_fornecedor`) REFERENCES `tbl_fornecedor` (`id_fornecedor`),
  CONSTRAINT `FK_tbl_fornecedor_telefone_tbl_telefone` FOREIGN KEY (`id_telefone`) REFERENCES `tbl_telefone` (`id_telefone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_fornecedor_telefone` (`id_fornecedor`, `id_telefone`) VALUES (4, 193);
INSERT INTO `tbl_fornecedor_telefone` (`id_fornecedor`, `id_telefone`) VALUES (5, 194);
INSERT INTO `tbl_fornecedor_telefone` (`id_fornecedor`, `id_telefone`) VALUES (5, 195);


#
# TABLE STRUCTURE FOR: tbl_link
#

DROP TABLE IF EXISTS `tbl_link`;

CREATE TABLE `tbl_link` (
  `id_link` int(11) NOT NULL AUTO_INCREMENT,
  `nome_link` varchar(100) NOT NULL,
  `designacao_link` varchar(100) NOT NULL,
  `ip_lan_link` varchar(100) NOT NULL,
  `ip_wan_link` varchar(100) NOT NULL,
  `status_link` tinyint(1) NOT NULL DEFAULT '0',
  `backup_link` tinyint(1) NOT NULL DEFAULT '0',
  `id_tipo_velocidade` int(11) NOT NULL,
  `id_tipo_acesso` int(11) NOT NULL,
  `id_unidade` int(11) NOT NULL,
  `id_fornecedor` int(11) NOT NULL,
  PRIMARY KEY (`id_link`),
  KEY `FK_tbl_link_tbl_tipo_velocidade` (`id_tipo_velocidade`),
  KEY `FK_tbl_link_tbl_tipo_acesso` (`id_tipo_acesso`),
  KEY `FK_tbl_link_tbl_unidade` (`id_unidade`),
  KEY `FK_tbl_link_tbl_fornecedor` (`id_fornecedor`),
  CONSTRAINT `FK_tbl_link_tbl_fornecedor` FOREIGN KEY (`id_fornecedor`) REFERENCES `tbl_fornecedor` (`id_fornecedor`),
  CONSTRAINT `FK_tbl_link_tbl_tipo_acesso` FOREIGN KEY (`id_tipo_acesso`) REFERENCES `tbl_tipo_acesso` (`id_tipo_acesso`),
  CONSTRAINT `FK_tbl_link_tbl_tipo_velocidade` FOREIGN KEY (`id_tipo_velocidade`) REFERENCES `tbl_tipo_velocidade` (`id_tipo_velocidade`),
  CONSTRAINT `FK_tbl_link_tbl_unidade` FOREIGN KEY (`id_unidade`) REFERENCES `tbl_unidade` (`id_unidade`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (1, mba_cecomt_mba, MBA/IP/00615, 10.2.204.10, 200.208.16.38, 1, 0, 5, 6, 14, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (2, chia_cecomt_chia, CHIA/IP/00103, 10.2.150.2, 189.2.78.178, 1, 0, 4, 6, 16, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (3, chia_cecomt_gurupi_b, CHIA/IP/00104, 10.2.150.3, 201.56.182.62, 1, 1, 3, 6, 16, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (4, bcn_oeat_bcn, BGN/IP/00119, 10.2.122.10, 201.31.147.230, 1, 0, 5, 6, 24, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (5, cpc_oeat_cpc, CPC/IP/00104, 10.2.85.10, 201.90.230.10, 1, 0, 2, 6, 28, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (6, cme_oeat_cme, CME/IP/00108, 10.2.62.10, 201.31.147.50, 1, 0, 3, 6, 26, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (7, blm_sopf_cppnf, BLM/IP/06484, 10.2.111.10, 201.31.147.202, 1, 0, 6, 6, 68, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (8, sip_oeat_sip, SIP/IP/00126, 10.2.23.10, 201.31.147.82, 1, 0, 5, 6, 52, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (9, smg_oeat_smg, SMG/IP/00107, 10.2.24.10, 201.31.147.162, 1, 0, 3, 2, 57, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (10, vgi_oeat_vgi, VGI/IP/00109, 10.2.22.10, 201.56.182.114, 1, 0, 2, 6, 64, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (11, jun_oeat_jun, JUN/IP/00104, 10.2.31.10, 201.31.20.254, 1, 0, 3, 6, 39, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (12, rnp_oeat_rnp, RNP/IP/00113, 10.2.34.10, 201.31.147.158, 1, 0, 3, 6, 50, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (13, sgz_oeat_sgz, SGZ/IP/00002, 10.2.39.10, 189.86.159.186, 1, 0, 4, 6, 56, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (14, srm_cerat_srm, SRM/IP/00442, 10.2.40.10, 200.246.150.90, 1, 0, 6, 6, 11, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (15, iab_oeat_iab, IAB/IP/00183, 10.2.41.10, 200.212.199.178, 1, 0, 5, 6, 37, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (16, ois_oeat_ois, OIS/IP/00111, 10.2.47.10, 201.31.147.198, 1, 0, 3, 6, 45, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (17, mng_oeat_mng, MNG/IP/00105, 10.2.46.10, 189.16.215.86, 1, 0, 3, 6, 42, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (18, por_oeat_por, POR/IP/00102, 10.2.51.10, 201.31.147.194, 1, 0, 3, 6, 49, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (20, rdo_cerat_rdo, RDO/IP/00219, 10.2.70.10, 201.31.147.14, 1, 0, 5, 6, 10, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (21, tca_oeat_tca, TCA/IP/00110, 10.2.76.10, 201.31.147.154, 1, 0, 3, 6, 61, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (22, xga_oeat_xga, XGA/IP/00114, 10.2.73.10, 201.31.147.138, 1, 0, 3, 6, 65, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (23, sxu_oeat_sxu, SXU/IP/00111, 10.2.74.10, 201.31.147.226, 1, 0, 3, 6, 55, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (25, sas_oeat_sas, SAS/IP/00116, 10.2.123.10, 201.56.182.94, 1, 0, 3, 6, 51, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (26, tla_oeat_tla, TLA/IP/00105, 10.2.131.10, 201.56.182.90, 1, 0, 3, 6, 59, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (27, tou_oeat_tou, TOU/IP/00107, 10.2.130.10, 189.86.159.146, 1, 0, 3, 6, 60, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (28, nvrp_oeat_nvrp, NVRP/IP/00103, 10.2.230.10, 189.86.159.142, 1, 0, 3, 6, 44, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (29, blm_uecomt_pratinha, BLM/IP/06483, 10.2.146.10, 201.31.20.246, 1, 0, 6, 6, 83, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (30, saf_uecomt_saf, SAF/IP/00101, 10.2.147.10, 201.56.182.54, 1, 0, 4, 6, 30, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (31, blm_uecomt_correios, BLM/IP/06482, 10.2.142.10, 189.86.159.58, 1, 0, 6, 6, 76, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (32, bcn_uecomt_bcn, BCN/IP/00301, 10.2.213.10, 201.56.182.86, 1, 0, 5, 6, 87, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (33, blm_uecomt_cais, BLM/IP/06477, 10.2.211.10, 200.241.240.222, 1, 0, 6, 6, 73, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (34, blm_uecomt_porto_sec, BLM/IP/06480, 10.2.218.10, 189.86.159.54, 1, 0, 6, 6, 82, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (35, blm_uecomt_aeroporto, BLM/IP/06481, 10.2.212.10, 200.241.240.230, 1, 0, 6, 6, 71, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (36, cir_cecomt_cir, CIR/IP/00122, 10.2.200.10, 201.31.147.142, 1, 0, 5, 6, 15, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (37, bacs_uecomt_bacs, SGU/IP/00105, 10.2.203.10, 189.86.159.182, 1, 0, 4, 6, 72, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (38, deu_cecomt_deu, DEU/IP/00106, 10.2.17.10, 201.31.147.118, 1, 0, 5, 6, 17, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (39, npso_cecomt_npso, NPSO/IP/00108, 10.2.152.10, 201.56.182.102, 1, 0, 4, 6, 19, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (41, afgo_uecomt_afgo, AFGO/IP/00002, 10.2.19.10, 201.31.147.130, 1, 0, 4, 6, 74, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (42, sgz_uecomt_sgz, SGZ/IP/00003, 10.2.203.10, 201.90.230.22, 1, 0, 4, 6, 85, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (43, mba_uecomt_frcarajas, MBA/IP/00614, 10.2.216.10, 201.31.147.74, 1, 0, 4, 6, 78, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (44, edra_oeat_edra, EDRA/IP/00106, 10.2.35.10, 201.31.147.218, 1, 0, 3, 6, 33, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (45, cyh_uecomt_cyh, CYH/IP/00002, 10.2.53.10, 201.31.147.70, 1, 0, 3, 6, 77, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (46, swi_blm_sefa_ananindeua, , 10.2.91.10, 10.99.15.225, 1, 0, 13, 3, 22, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (47, rad_moj_sefa, , 10.2.220.1, 10.2.220.10, 1, 0, 5, 1, 41, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (48, rad_cpn_sefa, , 10.2.62.10, , 1, 0, 13, 3, 26, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (49, rad_igc_sefa, , 10.2.21.10, 10.2.21.1, 1, 0, 5, 1, 35, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (50, rad_igm_sefa, , 10.2.242.1, 10.2.242.10, 1, 0, 5, 1, 36, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (51, rad_iab_sefa, , 10.2.68.10, 10.2.68.1, 1, 0, 5, 1, 37, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (52, rad_pcj_sefa, , 10.2.109.10, 10.2.109.1, 1, 0, 5, 1, 47, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (53, rad_uau_sefa, , 10.2.101.10, 10.2.101.1, 1, 0, 5, 1, 63, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (54, rad_cah_telecentro, , 10.2.20.10, 10.99.22.22, 1, 0, 13, 3, 6, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (55, rad_mba_sefa, , 10.2.179.10, 10.2.179.1, 1, 0, 5, 1, 29, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (56, rad_pba_sefa, , 10.2.37.1, 10.2.37.10, 1, 0, 6, 1, 48, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (57, rad_sas_sefa, , 10.2.123.10, 10.2.123.1, 1, 0, 5, 1, 51, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (58, rad_sip_sefa, , 10.2.241.10, 10.2.241.1, 1, 0, 5, 1, 52, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (59, rad_abt_sefa-ufpa, , 10.2.60.10, 10.101.35.10, 1, 0, 13, 3, 1, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (60, swi_red_sefa, , 10.2.70.10, 10.99.34.40, 1, 0, 7, 3, 10, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (61, swi_alt_sefa, , 10.2.100.10, 10.99.24.12, 1, 0, 13, 3, 2, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (62, swi_tuc_sefa, , 10.2.239.10, 10.99.31.15, 1, 0, 13, 3, 12, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (63, swmtr-para_sefa_cerat-01, , 10.2.80.10, 10.99.30.40, 1, 0, 13, 3, 9, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (64, swi_mtub_sefa, , 10.2.90.10, 10.99.15.227, 1, 0, 13, 3, 8, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (65, swi_breves_sefa, , 10.2.50.1, 10.2.50.10, 1, 0, 13, 3, 4, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (66, swi_blm_sefa, , 10.2.145.10, 10.99.3.9, 1, 0, 13, 3, 80, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (67, swi_blm_sefa efaz, , 10.2.110.10, 10.99.15.251, 1, 0, 13, 3, 67, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (68, swi_blm_sefa_ceasa, , 10.2.149.10, 10.2.149.5, 1, 0, 13, 3, 75, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (69, swi_blm_sefa_grandes_contribuintes, , 10.2.180.10, 10.99.15.224, 1, 0, 13, 3, 88, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (70, swi_san sefa uecomt, , 10.2.215.10, 10.99.21.110, 1, 0, 13, 3, 84, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (71, swi_sefa_cerat_metro maraba, , 10.2.30.10, 10.99.23.40, 1, 0, 13, 3, 7, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (72, rad_cnaa_sefa - oeat, , 10.2.38.1, 10.2.38.10, 1, 0, 7, 1, 27, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (73, rad_cpn_sefa cerat capanema - sede, , 10.2.120.1, 10.2.120.10, 1, 0, 13, 1, 5, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (74, swi_blm_sefa_gentil, , 10.2.12.10, 10.2.13.10, 10.99.3.2, 1, 0, 13, 3, 3, 2);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (75, swi_blm_sefa cecomt, , 10.2.140.10, 10.99.15.18, 1, 0, 13, 3, 13, 2);


#
# TABLE STRUCTURE FOR: tbl_perfil
#

DROP TABLE IF EXISTS `tbl_perfil`;

CREATE TABLE `tbl_perfil` (
  `id_perfil` int(11) NOT NULL AUTO_INCREMENT,
  `nome_perfil` varchar(100) NOT NULL,
  `comentario_perfil` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_perfil`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_perfil` (`id_perfil`, `nome_perfil`, `comentario_perfil`) VALUES (1, Usuario Comum, NULL);
INSERT INTO `tbl_perfil` (`id_perfil`, `nome_perfil`, `comentario_perfil`) VALUES (2, Administrador, NULL);
INSERT INTO `tbl_perfil` (`id_perfil`, `nome_perfil`, `comentario_perfil`) VALUES (3, Super Admin, NULL);


#
# TABLE STRUCTURE FOR: tbl_servico
#

DROP TABLE IF EXISTS `tbl_servico`;

CREATE TABLE `tbl_servico` (
  `id_servico` int(11) NOT NULL AUTO_INCREMENT,
  `nome_servico` varchar(100) NOT NULL,
  `comentario_servico` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_servico`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_servico` (`id_servico`, `nome_servico`, `comentario_servico`) VALUES (1, Link de Dados, NULL);
INSERT INTO `tbl_servico` (`id_servico`, `nome_servico`, `comentario_servico`) VALUES (2, Roteador /  Switchs, NULL);
INSERT INTO `tbl_servico` (`id_servico`, `nome_servico`, `comentario_servico`) VALUES (3, Servidores / Storage /Library, NULL);
INSERT INTO `tbl_servico` (`id_servico`, `nome_servico`, `comentario_servico`) VALUES (4, Nobreak / Gerador, NULL);
INSERT INTO `tbl_servico` (`id_servico`, `nome_servico`, `comentario_servico`) VALUES (5, Central de ar, NULL);
INSERT INTO `tbl_servico` (`id_servico`, `nome_servico`, `comentario_servico`) VALUES (6, Software, NULL);


#
# TABLE STRUCTURE FOR: tbl_telefone
#

DROP TABLE IF EXISTS `tbl_telefone`;

CREATE TABLE `tbl_telefone` (
  `id_telefone` int(11) NOT NULL AUTO_INCREMENT,
  `numero_telefone` varchar(30) NOT NULL,
  `id_tipo_categoria_telefone` int(11) NOT NULL,
  PRIMARY KEY (`id_telefone`),
  UNIQUE KEY `numero_telefone` (`numero_telefone`),
  KEY `FK_tbl_telefone_tbl_tipo_categoria_telefone` (`id_tipo_categoria_telefone`),
  CONSTRAINT `FK_tbl_telefone_tbl_tipo_categoria_telefone` FOREIGN KEY (`id_tipo_categoria_telefone`) REFERENCES `tbl_tipo_categoria_telefone` (`id_tipo_categoria_telefone`)
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (1, (91) 3323-4477, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (2, (91) 3323-3599, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (3, (91) 3323-4448, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (4, (91) 3323-3884, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (5, (91) 3323-4480, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (6, (91) 3323-3853, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (7, (91) 3323-4483, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (8, (91) 3323-4473, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (9, (91) 3323-3871, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (10, (91) 3323-4476, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (11, (91) 3323-4475, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (12, (91) 3323-4482, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (13, (91) 3323-3873, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (14, (91) 3323-3870, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (15, (91) 3323-3872, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (16, (91) 9882-9610, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (17, (91) 3323-4333, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (18, (91) 3323-3859, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (19, (91) 3323-3860, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (20, (91) 3323-4439, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (21, (91) 4005-8145, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (22, (91) 98418-0579, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (23, (91) 4005-8118, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (24, (91) 98405-4591, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (25, (94) 2101-9991, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (26, (94) 98409-9910, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (27, (91) 3235-5201, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (28, (91) 98425-3750, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (29, (91) 3323-4472, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (30, (91) 3323-4498, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (31, (91) 3323-4935, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (32, (91) 3323-4429, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (33, (91) 3323-3877, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (34, (91) 3323-3876, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (35, (91) 3323-3890, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (36, (91) 3323-3875, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (37, (91) 3323-4412, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (40, (91) 3323-4492, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (42, (31) 2121-3840, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (43, (31) 2121-3846, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (44, (31) 2121-3710, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (45, (91) 4005-8172, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (46, (91) 98436-3255, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (47, (61) 2106-8228, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (48, (61) 99272-3224, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (49, (91) 4005-8114, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (50, (91) 98412-3323, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (51, (91) 4005-8442, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (52, (91) 98441-2329, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (53, (91) 4005-8254, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (54, (91) 98467-8335, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (57, (91) 4005-8451, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (58, (91) 4005-8214, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (59, (91) 3184-4609, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (60, (91) 3184-4600, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (61, (91) 98256-2958, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (62, (91) 3323-4400, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (63, (99) 99158-2663, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (64, (99) 99189-7761, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (65, (98) 98130-5999, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (66, (98) 98259-8440, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (67, (91) 9825-05185, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (68, (91) 9930-02728, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (69, (94) 98174-4942, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (70, (94) 9810-00666, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (71, (94) 99240-1855, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (72, (91) 98193-0381, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (73, (91) 98982-2806, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (74, (93) 99129-0154, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (75, (91) 98829-6109, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (76, (91) 98743-1380, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (77, (94) 99172-3043, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (78, (91) 98163-4393, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (79, (94) 99167-5840, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (80, (94) 9812-24836, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (81, (94) 3779-1662, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (82, (91) 3441-1266, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (83, (93) 3518-1645, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (84, (91) 3353-2062, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (85, (94) 3345-1416, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (86, (91) 3444-1191, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (87, (93) 3533-1420, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (88, (94) 3785-1212, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (89, (93) 3547-1359, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (90, (93) 3544-1238, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (91, (91) 3798-1227, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (92, (94) 3346-1103, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (93, (91) 3784-1218, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (94, (94) 3326-1265, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (95, (91) 3423-2498, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (96, (91) 3744-1171, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (97, (94) 3332-1178, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (98, (94) 3331-1205, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (99, (91) 3323-4496, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (100, (91) 3752-1170, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (101, (91) 3727-1206, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (102, (94) 3433-3504, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (103, (93) 3532-1643, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (104, (91) 3731-1278, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (105, (91) 3241-3841, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (106, (91) 3241-5284, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (107, (91) 3244-9433, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (108, (91) 3244-9661, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (109, (91) 3257-4800, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (110, (91) 3225-1596, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (111, (91) 3323-3593, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (114, (91) 3272-8323, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (115, (91) 3264-6757, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (116, (91) 3258-1602, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (117, (94) 3382-3064, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (118, (94) 9234-4632, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (119, (94) 9174-6440, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (120, (91) 3323-3868, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (121, (91) 3754-0805, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (122, (91) 3184-4563, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (123, (91) 3184-4573, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (124, (91) 3184-4555, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (125, (91) 3184-4550, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (129, (91) 3323-4402, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (130, (91) 3323-4936, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (132, (91) 3323-4408, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (133, (91) 3323-4418, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (134, (91) 3323-4436, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (135, (91) 3323-3592, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (136, (91) 3323-4447, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (139, (91) 3323-4419, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (140, (91) 3323-4409, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (141, (91) 3323-3595, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (142, (91) 3323-3882, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (143, (91) 3323-3864, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (144, (91) 3323-3869, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (145, (91) 3323-4487, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (146, (91) 3323-4437, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (147, (91) 3323-3852, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (148, (91) 3323-3862, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (149, (91) 3323-4438, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (150, (91) 3323-4434, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (151, (91) 3323-4432, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (152, (91) 3323-4430, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (153, (91) 3323-3866, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (154, (91) 3323-4407, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (155, (91) 3323-4425, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (156, (91) 3323-4424, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (157, (91) 3323-3857, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (158, (91) 3323-4423, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (159, (91) 3323-4422, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (160, (91) 3323-4421, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (161, (91) 3323-4417, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (162, (91) 3323-3888, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (163, (91) 3323-4416, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (164, (91) 3323-4415, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (165, (91) 3323-4414, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (166, (91) 3323-4411, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (167, (91) 3323-44, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (168, (91) 3323-4406, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (169, (91) 3323-4405, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (170, (91) 3323-4404, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (171, (91) 3323-4403, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (172, (91) 3323-4401, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (173, (91) 3323-3874, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (174, (91) 3323-3896, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (175, (91) 3323-3856, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (176, (91) 3323-4493, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (177, (91) 3323-4491, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (178, (91) 3323-4489, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (179, (91) 3323-4488, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (180, (91) 3323-4435, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (181, (91) 3323-3851, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (182, (91) 3323-4428, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (183, (91) 3323-4297, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (184, (91) 3323-4988, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (185, (91) 3323-4984, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (188, (91) 3323-4994, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (189, (91) 3323-4951, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (190, (91) 3323-4950, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (191, (91) 3323-4969, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (192, (91) 3323-4446, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (193, (31) 3244-6969, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (194, (19) 3090-1907, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (195, (19) 3090-1908, 1);


#
# TABLE STRUCTURE FOR: tbl_telefone_voip
#

DROP TABLE IF EXISTS `tbl_telefone_voip`;

CREATE TABLE `tbl_telefone_voip` (
  `id_telefone_voip` int(11) NOT NULL AUTO_INCREMENT,
  `ip_telefone_voip` varchar(15) NOT NULL,
  `descricao_telefone_voip` varchar(100) NOT NULL,
  `id_telefone` int(11) NOT NULL,
  `id_tipo_categoria_voip` int(11) NOT NULL,
  `id_tipo_equipamento_voip` int(11) NOT NULL,
  `id_tipo_contexto_voip` int(11) NOT NULL,
  PRIMARY KEY (`id_telefone_voip`),
  UNIQUE KEY `id_telefone` (`id_telefone`),
  KEY `id_tipo_categoria` (`id_tipo_categoria_voip`),
  KEY `id_tipo_equipamento` (`id_tipo_equipamento_voip`),
  KEY `id_tipo_contexto` (`id_tipo_contexto_voip`),
  CONSTRAINT `FK_tbl_telefone_voip_tbl_telefone` FOREIGN KEY (`id_telefone`) REFERENCES `tbl_telefone` (`id_telefone`),
  CONSTRAINT `FK_tbl_telefone_voip_tbl_tipo_categoria_voip` FOREIGN KEY (`id_tipo_categoria_voip`) REFERENCES `tbl_tipo_categoria_voip` (`id_tipo_categoria_voip`),
  CONSTRAINT `FK_tbl_telefone_voip_tbl_tipo_contexto_voip` FOREIGN KEY (`id_tipo_contexto_voip`) REFERENCES `tbl_tipo_contexto_voip` (`id_tipo_contexto_voip`),
  CONSTRAINT `FK_tbl_telefone_voip_tbl_tipo_equipamento_voip` FOREIGN KEY (`id_tipo_equipamento_voip`) REFERENCES `tbl_tipo_equipamento_voip` (`id_tipo_equipamento_voip`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (1, 10.2.60.107, , 1, 2, 2, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (2, 10.2.140.10, , 2, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (3, 10.2.204.100, , 3, 2, 2, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (4, 10.2.204.10, , 4, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (5, 10.2.200.180, Fiscalização, 5, 2, 2, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (6, 10.2.200.10, , 6, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (7, 10.2.150.102, , 7, 2, 1, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (8, 10.2.150.102, , 8, 2, 1, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (9, 10.2.17.10, , 9, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (10, 10.2.17.101, , 10, 2, 2, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (11, 10.2.17.106, , 11, 2, 1, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (12, 10.2.17.106, , 12, 2, 1, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (13, 10.2.210.10, , 13, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (14, 10.2.210.10, , 14, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (15, 10.2.210.10, , 15, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (16, , , 16, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (17, 10.2.152.10, , 17, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (18, 10.2.152.10, , 18, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (19, 10.2.60.10, , 19, 2, 3, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (20, 10.2.100.10, , 20, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (21, 10.2.100.43, , 29, 2, 2, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (22, 10.2.12.8, , 30, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (23, 10.2.50.10, Administrativo, 31, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (24, 10.2.20.10, , 32, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (25, 10.2.90.10, , 33, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (26, 10.2.90.10, , 34, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (27, 10.2.90.10, , 35, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (28, 10.2.90.10, , 36, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (29, 10.2.80.10, , 37, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (32, 10.2.239.10, , 40, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (33, 10.2.147.10, , 62, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (34, 10.2.40.10, , 129, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (35, 10.2.50.1, Administrativo, 130, 1, 1, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (36, 10.2.70.10, , 132, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (37, 10.2.212.10, , 133, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (38, 10.2.206.10, , 134, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (39, 10.2.211.10, , 135, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (40, 10.2.19.100, , 136, 2, 1, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (41, 10.2.216.10, , 139, 3, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (42, 10.2.145.10, , 140, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (43, 10.2.219.10, , 141, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (44, 10.2.218.10, , 142, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (45, 10.2.146.10, , 143, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (46, 10.2.205.10, , 144, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (47, 10.2.208.10, , 145, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (48, 10.2.213.10, , 146, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (49, 10.2.52.10, , 147, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (50, 10.2.42.10, , 148, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (51, 10.2.61.10, , 149, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (52, 10.2.234.10, , 150, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (53, 10.2.62.10, , 151, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (54, 10.2.85.10, , 152, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (55, 10.2.33.10, , 153, 1, 2, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (56, 10.2.83.10, , 154, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (57, 10.2.36.10, , 155, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (58, 10.2.21.10, , 156, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (59, 10.2.41.10, , 157, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (60, 10.2.238.10, , 158, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (61, 10.2.31.10, , 159, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (62, 10.2.82.10, , 160, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (63, 10.2.16.10, , 161, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (64, 10.2.44.10, , 162, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (65, 10.2.230.10, , 163, 1, 2, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (66, 10.2.47.10, , 164, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (67, 10.2.43.10, , 165, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (68, 10.2.37.10, , 166, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (69, 10.2.51.10, , 167, 1, 2, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (70, 10.2.34.10, , 168, 1, 2, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (71, 10.2.123.10, , 169, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (72, 10.2.23.10, , 170, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (73, 10.2.77.10, , 171, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (74, 10.2.232.10, , 172, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (75, 10.2.74.10, , 173, 1, 2, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (76, 10.2.39.10, , 174, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (77, 10.2.24.10, , 175, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (78, 10.2.76.10, , 176, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (79, 10.2.84.10, , 177, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (80, 10.2.22.10, , 178, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (81, 10.2.73.10, , 179, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (82, 10.2.122.10, , 180, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (83, 10.2.118.10, , 181, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (84, 10.2.113.10, , 182, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (85, 10.3.0.189, , 183, 1, 2, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (86, 10.3.0.201, , 184, 2, 1, 2);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (87, 10.3.0.200, , 185, 1, 2, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (88, 10.3.0.221, , 188, 1, 2, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (89, 10.2.12.163, , 189, 2, 2, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (90, 10.2.12.162, , 190, 2, 2, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (91, 10.3.0.232, , 191, 2, 2, 4);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (92, 10.3.0.75, , 192, 2, 2, 7);


#
# TABLE STRUCTURE FOR: tbl_tipo_acesso
#

DROP TABLE IF EXISTS `tbl_tipo_acesso`;

CREATE TABLE `tbl_tipo_acesso` (
  `id_tipo_acesso` int(11) NOT NULL AUTO_INCREMENT,
  `nome_tipo_acesso` varchar(100) NOT NULL,
  `comentario_tipo_acesso` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_tipo_acesso`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_tipo_acesso` (`id_tipo_acesso`, `nome_tipo_acesso`, `comentario_tipo_acesso`) VALUES (1, Rádio, NULL);
INSERT INTO `tbl_tipo_acesso` (`id_tipo_acesso`, `nome_tipo_acesso`, `comentario_tipo_acesso`) VALUES (2, Satélite, NULL);
INSERT INTO `tbl_tipo_acesso` (`id_tipo_acesso`, `nome_tipo_acesso`, `comentario_tipo_acesso`) VALUES (3, Fibra Óptica, );
INSERT INTO `tbl_tipo_acesso` (`id_tipo_acesso`, `nome_tipo_acesso`, `comentario_tipo_acesso`) VALUES (4, Dial modem, );
INSERT INTO `tbl_tipo_acesso` (`id_tipo_acesso`, `nome_tipo_acesso`, `comentario_tipo_acesso`) VALUES (5, XDSL, );
INSERT INTO `tbl_tipo_acesso` (`id_tipo_acesso`, `nome_tipo_acesso`, `comentario_tipo_acesso`) VALUES (6, Terrestre, );


#
# TABLE STRUCTURE FOR: tbl_tipo_categoria_telefone
#

DROP TABLE IF EXISTS `tbl_tipo_categoria_telefone`;

CREATE TABLE `tbl_tipo_categoria_telefone` (
  `id_tipo_categoria_telefone` int(11) NOT NULL AUTO_INCREMENT,
  `nome_tipo_categoria_telefone` varchar(100) NOT NULL,
  `comentario_tipo_categoria_telefone` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_tipo_categoria_telefone`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_tipo_categoria_telefone` (`id_tipo_categoria_telefone`, `nome_tipo_categoria_telefone`, `comentario_tipo_categoria_telefone`) VALUES (1, Fixo, NULL);
INSERT INTO `tbl_tipo_categoria_telefone` (`id_tipo_categoria_telefone`, `nome_tipo_categoria_telefone`, `comentario_tipo_categoria_telefone`) VALUES (2, Celular, NULL);
INSERT INTO `tbl_tipo_categoria_telefone` (`id_tipo_categoria_telefone`, `nome_tipo_categoria_telefone`, `comentario_tipo_categoria_telefone`) VALUES (3, Ramal, NULL);
INSERT INTO `tbl_tipo_categoria_telefone` (`id_tipo_categoria_telefone`, `nome_tipo_categoria_telefone`, `comentario_tipo_categoria_telefone`) VALUES (4, Voip, NULL);


#
# TABLE STRUCTURE FOR: tbl_tipo_categoria_voip
#

DROP TABLE IF EXISTS `tbl_tipo_categoria_voip`;

CREATE TABLE `tbl_tipo_categoria_voip` (
  `id_tipo_categoria_voip` int(11) NOT NULL AUTO_INCREMENT,
  `nome_tipo_categoria_voip` varchar(100) NOT NULL,
  `comentario_tipo_categoria_voip` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_tipo_categoria_voip`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_tipo_categoria_voip` (`id_tipo_categoria_voip`, `nome_tipo_categoria_voip`, `comentario_tipo_categoria_voip`) VALUES (1, FXS, NULL);
INSERT INTO `tbl_tipo_categoria_voip` (`id_tipo_categoria_voip`, `nome_tipo_categoria_voip`, `comentario_tipo_categoria_voip`) VALUES (2, SIP, NULL);
INSERT INTO `tbl_tipo_categoria_voip` (`id_tipo_categoria_voip`, `nome_tipo_categoria_voip`, `comentario_tipo_categoria_voip`) VALUES (3, New Bridge, NULL);
INSERT INTO `tbl_tipo_categoria_voip` (`id_tipo_categoria_voip`, `nome_tipo_categoria_voip`, `comentario_tipo_categoria_voip`) VALUES (4, teste, TESTE);
INSERT INTO `tbl_tipo_categoria_voip` (`id_tipo_categoria_voip`, `nome_tipo_categoria_voip`, `comentario_tipo_categoria_voip`) VALUES (6, nova categoria, teste);


#
# TABLE STRUCTURE FOR: tbl_tipo_contexto_voip
#

DROP TABLE IF EXISTS `tbl_tipo_contexto_voip`;

CREATE TABLE `tbl_tipo_contexto_voip` (
  `id_tipo_contexto_voip` int(11) NOT NULL AUTO_INCREMENT,
  `nome_tipo_contexto_voip` varchar(100) NOT NULL,
  `comentario_tipo_contexto_voip` varchar(100) NOT NULL,
  PRIMARY KEY (`id_tipo_contexto_voip`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_tipo_contexto_voip` (`id_tipo_contexto_voip`, `nome_tipo_contexto_voip`, `comentario_tipo_contexto_voip`) VALUES (1, Acesso Padrão, );
INSERT INTO `tbl_tipo_contexto_voip` (`id_tipo_contexto_voip`, `nome_tipo_contexto_voip`, `comentario_tipo_contexto_voip`) VALUES (2, Acesso Local Fixo, );
INSERT INTO `tbl_tipo_contexto_voip` (`id_tipo_contexto_voip`, `nome_tipo_contexto_voip`, `comentario_tipo_contexto_voip`) VALUES (3, Acesso Local Celular, );
INSERT INTO `tbl_tipo_contexto_voip` (`id_tipo_contexto_voip`, `nome_tipo_contexto_voip`, `comentario_tipo_contexto_voip`) VALUES (4, Acesso Fixo PA, );
INSERT INTO `tbl_tipo_contexto_voip` (`id_tipo_contexto_voip`, `nome_tipo_contexto_voip`, `comentario_tipo_contexto_voip`) VALUES (5, Acesso DDD Fixo, );
INSERT INTO `tbl_tipo_contexto_voip` (`id_tipo_contexto_voip`, `nome_tipo_contexto_voip`, `comentario_tipo_contexto_voip`) VALUES (6, Acesso DDD Celular, );
INSERT INTO `tbl_tipo_contexto_voip` (`id_tipo_contexto_voip`, `nome_tipo_contexto_voip`, `comentario_tipo_contexto_voip`) VALUES (7, Acesso Total, );


#
# TABLE STRUCTURE FOR: tbl_tipo_equipamento_voip
#

DROP TABLE IF EXISTS `tbl_tipo_equipamento_voip`;

CREATE TABLE `tbl_tipo_equipamento_voip` (
  `id_tipo_equipamento_voip` int(11) NOT NULL AUTO_INCREMENT,
  `nome_tipo_equipamento_voip` varchar(100) NOT NULL,
  `comentario_tipo_equipamento_voip` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_tipo_equipamento_voip`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_tipo_equipamento_voip` (`id_tipo_equipamento_voip`, `nome_tipo_equipamento_voip`, `comentario_tipo_equipamento_voip`) VALUES (1, ATA - Linksys, );
INSERT INTO `tbl_tipo_equipamento_voip` (`id_tipo_equipamento_voip`, `nome_tipo_equipamento_voip`, `comentario_tipo_equipamento_voip`) VALUES (2, Telefone IP, NULL);
INSERT INTO `tbl_tipo_equipamento_voip` (`id_tipo_equipamento_voip`, `nome_tipo_equipamento_voip`, `comentario_tipo_equipamento_voip`) VALUES (3, Telefone Analógico, NULL);


#
# TABLE STRUCTURE FOR: tbl_tipo_velocidade
#

DROP TABLE IF EXISTS `tbl_tipo_velocidade`;

CREATE TABLE `tbl_tipo_velocidade` (
  `id_tipo_velocidade` int(11) NOT NULL AUTO_INCREMENT,
  `nome_tipo_velocidade` varchar(100) NOT NULL,
  `comentario_tipo_velocidade` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_tipo_velocidade`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (1, 64, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (2, 128, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (3, 256, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (4, 512, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (5, 1024, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (6, 2048, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (7, 4096, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (8, 8192, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (9, 16384, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (10, 2048, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (11, 384, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (12, 6144, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (13, 10240, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (14, 34816, NULL);


#
# TABLE STRUCTURE FOR: tbl_unidade
#

DROP TABLE IF EXISTS `tbl_unidade`;

CREATE TABLE `tbl_unidade` (
  `id_unidade` int(11) NOT NULL AUTO_INCREMENT,
  `nome_unidade` varchar(100) NOT NULL,
  `endereco_unidade` varchar(100) NOT NULL,
  `status_unidade` tinyint(1) NOT NULL DEFAULT '1',
  `comentario_unidade` varchar(100) DEFAULT NULL,
  `id_unidade_responsavel` int(11) DEFAULT NULL,
  `id_cidade` int(11) NOT NULL,
  `id_expediente` int(11) NOT NULL,
  PRIMARY KEY (`id_unidade`),
  KEY `FK_tbl_unidade_tbl_cidade` (`id_cidade`),
  KEY `FK_tbl_unidade_tbl_expediente` (`id_expediente`),
  KEY `FK_tbl_unidade_tbl_unidade` (`id_unidade_responsavel`),
  CONSTRAINT `FK_tbl_unidade_tbl_cidade` FOREIGN KEY (`id_cidade`) REFERENCES `tbl_cidade` (`id_cidade`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_tbl_unidade_tbl_expediente` FOREIGN KEY (`id_expediente`) REFERENCES `tbl_expediente` (`id_expediente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_tbl_unidade_tbl_unidade` FOREIGN KEY (`id_unidade_responsavel`) REFERENCES `tbl_unidade` (`id_unidade`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (1, CERAT Abaetetuba, Av. Pedro Rodrigues, 140 - Centro., 1, , NULL, 1, 2);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (2, CERAT Altamira, Rua Otaviano Santos 2296, 1, NULL, NULL, 8, 2);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (3, CERAT Belém, Av. Gentil Bittencurt 256, São Braz, 1, , NULL, 19, 3);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (4, CERAT Breves, Rua Dra. Wilson Frazão, 348, 1, , NULL, 28, 3);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (5, CERAT Capanema, End.: Rua João Pessoa, 109, centro, 1, , NULL, 34, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (6, CERAT Castanhal, Rua Paes de Carvalho 1128-Centro, 1, , NULL, 36, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (7, CERAT Marabá, Rod. Transamazônica, km 05, 1, , NULL, 66, 2);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (8, CERAT Marituba, Rod. BR 316 s/n km 13 - ao lado da prefeitura de Marituba, em frente ao Jotão, 1, , NULL, 69, 2);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (9, CERAT Paragominas, Av. Presidente Vargas s/n - Próximo ao Hospital Municipal, 1, , NULL, 89, 2);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (10, CERAT Redenção, Av. Marechal Rondon, 855 Núcleo Urbano, 1, , NULL, 101, 2);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (11, CERAT Santarém, AV. Mendonça Furtado, 2797 - Fátima, 1, , NULL, 114, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (12, CERAT Tucurui, Av. Aluísio Chaves 155, esquina com a Av. Fernando Guilhon, Nova Tucuruí, 1, , NULL, 138, 2);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (13, CECOMT Belém, Trav João Balbi, Nº 207, 1, , NULL, 19, 2);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (14, CECOMT Carajás, Rod -. Transamazônica, Km 9 Marabá, 1, , NULL, 66, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (15, CECOMT Conceição do Araguaia , Rodovia Pa-447 Km 15, 1, , NULL, 39, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (16, CECOMT Gurupi, Rod. BR-316, Km 280, 1, , NULL, 31, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (17, CECOMT Itinga , Rod. BR 010 km 1481 -Fronteira Pará/Maranhão Vila Bela Vista , 1, , NULL, 46, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (18, CECOMT Portos e Aeroportos , Av. D. Pedro I 1097, 1, , NULL, 19, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (19, CECOMT Serra do Cachimbo , BR 63 Santarém Cuiabá km 970, 1, , NULL, 80, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (20, OEAT Afuá, Rua Mariano Cândido S/N., 1, , 4, 4, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (21, OEAT Almerim, Rua Amândido Pantoja S/N, 1, , 11, 7, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (22, OEAT Ananindeua, Rod. Br 316 Km 05, 1, , 8, 10, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (23, OEAT Barcarena, Av. Cronge da Silveira 488  Centro., 1, , 1, 18, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (24, OEAT Bragança, Av. Marechal Floriano Peixoto, S/N, 1, , 5, 24, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (25, OEAT Breu Branco, Rod Pa, 263, Km 12, 1, , 12, 27, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (26, OEAT Cametá, Praça Deodoro da Fonseca, 485, 1, , 1, 32, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (27, OEAT Canaã dos Carajás, Rua, 0, , 7, 66, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (28, OEAT Capitão Poço, Av. 29 de Dezembro s/n, centro, 1, , 9, 35, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (29, OEAT Cidade Nova Marabá, Rua Frei Raimundo Lambezart, 1814, 1, , 7, 66, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (30, UECOMT São Francisco, BR 316, s/n - km 82 - Município de São Francisco, 1, , 13, 121, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (31, OEAT Conceição do Araguaia, Rua 30 de maio S/N. Centro, 1, , 10, 39, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (32, OEAT Dom Eliseu, Marechal Rondon s/n, centro, 1, , 9, 46, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (33, OEAT Eldorado dos Carajás, Rod. PA 150 km 100 S/N, 1, , 7, 47, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (34, OEAT Goianésia do Pará, Av. Tancredo Neves, S/N, 1, , 12, 51, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (35, OEAT Igarape Açu, Rua Lauro Sodré, 1, , 6, 53, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (36, OEAT Igarapé Mirim, Rua 15 de Novembro s/n, centro, 1, , 1, 54, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (37, OEAT Itaituba, Av. São José nº229-B,  Centro, 1, , 11, 58, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (38, OEAT Itupiranga, Rod. Transamazônica, km 42 - Agrovila, 1, , 7, 59, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (39, OEAT Jacundá, Av. Cristo Rei 672, 1, , 7, 61, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (40, OEAT Mãe do Rio, Bernardo Saião 265, centro, 1, , 9, 64, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (41, OEAT Moju, Falta atualizar o endereço, 1, , 1, 73, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (42, OEAT Monte Alegre, Bosque Dionizio Bentes s/n, cidade alta, 1, , 11, 75, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (43, OEAT Novo Progresso, Av. Ourival Prazeres, esquina c/ rua Olavo Bilaque - Ag. Perto Detran, 1, , 11, 80, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (44, OEAT Novo Repartimento, Rod. PA 230 Transamazônica Km 185, 1, , 12, 81, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (45, OEAT Obidos, Rua Marques Rodrigues de Souza S/N, 1, , 11, 82, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (46, OEAT Oriximiná, Av. Carlos Maria Teixeira, 160, 1, , 11, 84, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (47, OEAT Pacajás, Rod. Transamazônica, KM 282, 1, , 2, 87, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (48, OEAT Parauapebas, Rua F, nº 416 - Cidade Nova, 1, , 7, 90, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (49, OEAT Portel, Rua Floriano Peixoto, 761, 1, , 4, 96, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (50, OEAT Rondon do Pará, Av. Marechel Rondon S/N, 1, , 7, 103, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (51, OEAT Salinópolis, Trav. Pastor Vicente Rodrigues, S/N, centro, 1, , 5, 105, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (52, OEAT Santa Izabel do Pará, Rod. BR-316, km 41, 3268, 1, , 6, 109, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (53, OEAT Santana do Araguaia, Rua Hélio Rêgo, nº60 Q 26 L 02 - Bel Recanto, 1, , 10, 113, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (54, OEAT São Domingos do Araguaia, Av. Duque de Caxias, 85, 1, , 7, 118, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (55, OEAT São Félix do Xingu, Av. Rio Xingu, nº 2567 - Alecrim, 1, , 10, 120, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (56, OEAT São Geraldo do Araguaia, Av. Castelo Branco, 1181, 1, , 7, 122, 2);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (57, OEAT São Miguel do Guamá, Av. Tancredo Neves, 813, 1, , 6, 126, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (58, OEAT Soure, Rua 01, 318 - Próximo a Praça, 1, , 3, 130, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (59, OEAT Tailândia, Rod. PA 150, Km 130, 1, , 12, 131, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (60, OEAT Tomé-Açu, Av. Magalhães Barata, 728 – Centro, 1, , 12, 134, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (61, OEAT Tucumã, Rua do Café, 108 , Morumbi , 1, , 10, 137, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (62, OEAT Ulianópolis, BR 010 s/n, bairro do porto fiscal, 1, , 9, 139, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (63, OEAT Uruará, Rodovia Transamazônica, Km 180, Rua Perimetral Norte, Nº 82, 1, , 2, 140, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (64, OEAT Vigia, Av. General Gurjão, s/nº, 1, , 6, 141, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (65, OEAT Xinguara, Rua Marechal Cordeiro de Farias, sn , centro, 1, , 10, 144, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (66, CCDA - PGE, Conselheiro Furtado, 616. entre Travessa Padre Eutíquio e Travessa Apinagés, 1, , 13, 19, 3);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (67, EFAZ, Av. Conselheiro Furtado 558, 1, , 13, 19, 3);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (68, SOPF - CPPNF, Av.Pedro Miranda, 774, 1, , 13, 19, 3);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (69, Órgão Central, Av. Visconde de souza franco, 1, , NULL, 19, 3);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (70, DIPAT, Rua Municipalidade, 100, 1, , 13, 19, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (71, UECOMT Aeroporto, Term. de Cargas do Aeroporto, Base  Val de Cans, 1, , 18, 19, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (72, UECOMT Barreira do Campo, Rod. PA 411, Km 38 ou Av. Manoel Quintino s/n, 1, , 15, 113, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (73, UECOMT Cais do Porto, Marechal Hermes/Doca/Portão 17, 1, , 18, 19, 3);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (74, UECOMT Carne de Sol, Rod. Br 222, (Abel Figueiredo) km 78, 1, , 14, 2, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (75, UECOMT Ceasa, Área da CEASA - Galpão Posto SEFA, 1, , 13, 19, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (76, UECOMT Correios, Av. Senador Lemos, 1749, 1, , 13, 19, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (77, UECOMT Curralinho, Rua Florino Peixoto, S/N, 1, , 13, 43, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (78, UECOMT Ferrovia de Carajás, Rod. PA-150 KM 3 - Distrito Industrial, 1, , 7, 66, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (79, UECOMT Juary, Rod. PA 287 km 03, Aeroporto, 1, , 10, 101, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (80, UECOMT Litoral, Av. Bernardo Sayão 1718, jurunas, 1, , 13, 19, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (81, UECOMT Miramar, Av. Salgado Filho com arthur bernades S/N, terminal petroquimico, 1, , 18, 19, 3);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (82, UECOMT Porto Seco, Rod. Artur Bernades, pass. Pe Julião, 351 - Instalações da Reicon/Amazon Dry, 1, , 18, 19, 3);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (83, UECOMT Pratinha, Rod. Artur Bernardes, km 06 s/n. Icoaraci - Pratinha 1, próx. Base Aerea, 1, , 13, 19, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (84, UECOMT Santarém, Av. Cuiabá, s/n - Vera Paz (CDP), 1, , 18, 114, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (85, UECOMT São Geraldo do Araguaia, Av. Castelo Branco, S/N - Beira Rio, 1, , 14, 122, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (86, UECOMT São José - Pontão, Estrada da Fazenda Rio Vermelho km90 entre Rio Araguaia e Ro, 1, , 15, 144, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (87, UECOMT Vila do Conde, Rod. Pa 481, km2,3 - Complexo Portuário de Vila do Conde - Área Alfandegaria, 1, , 18, 18, 3);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (88, CEEAT Grandes Contribuintes, Tv. 14 de abril 2010 entre Munducus e Pariquis, 1, , NULL, 19, 3);


#
# TABLE STRUCTURE FOR: tbl_unidade_telefone
#

DROP TABLE IF EXISTS `tbl_unidade_telefone`;

CREATE TABLE `tbl_unidade_telefone` (
  `id_unidade` int(11) NOT NULL,
  `id_telefone` int(11) NOT NULL,
  PRIMARY KEY (`id_unidade`,`id_telefone`),
  KEY `FK_tbl_unidade_telefone_tbl_telefone_idx` (`id_telefone`),
  KEY `FK_tbl_unidade_telefone_tbl_unidade_idx` (`id_unidade`),
  CONSTRAINT `FK_tbl_unidade_telefone_tbl_telefone` FOREIGN KEY (`id_telefone`) REFERENCES `tbl_telefone` (`id_telefone`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_tbl_unidade_telefone_tbl_unidade` FOREIGN KEY (`id_unidade`) REFERENCES `tbl_unidade` (`id_unidade`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (1, 1);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (1, 19);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (2, 20);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (2, 29);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (3, 30);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (4, 31);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (4, 130);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (6, 32);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (8, 33);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (8, 34);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (8, 35);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (8, 36);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (9, 37);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (10, 132);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (11, 129);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (12, 40);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (13, 2);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (13, 59);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (13, 60);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (14, 3);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (14, 4);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (15, 5);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (15, 6);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (16, 7);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (16, 8);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (17, 9);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (17, 10);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (17, 11);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (17, 12);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (18, 13);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (18, 14);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (18, 15);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (18, 16);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (19, 17);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (19, 18);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (20, 147);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (21, 148);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (23, 149);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (24, 180);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (25, 150);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (26, 151);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (28, 152);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (29, 153);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (30, 61);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (30, 62);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (32, 154);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (34, 81);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (34, 155);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (35, 82);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (35, 156);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (37, 83);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (37, 157);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (38, 84);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (38, 158);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (39, 85);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (39, 159);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (40, 86);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (40, 160);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (42, 87);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (42, 161);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (43, 162);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (44, 88);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (44, 163);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (45, 89);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (45, 164);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (46, 90);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (46, 165);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (47, 91);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (48, 92);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (48, 166);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (49, 93);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (49, 167);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (50, 94);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (50, 168);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (51, 95);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (51, 169);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (52, 96);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (52, 170);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (53, 171);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (54, 97);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (54, 172);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (55, 173);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (56, 98);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (56, 174);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (57, 175);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (58, 99);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (59, 100);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (60, 101);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (61, 102);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (61, 176);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (62, 177);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (63, 103);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (64, 104);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (64, 178);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (65, 179);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (66, 181);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (67, 105);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (67, 106);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (68, 107);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (68, 108);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (69, 183);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (69, 184);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (69, 185);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (69, 188);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (69, 189);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (69, 190);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (69, 191);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (69, 192);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (70, 182);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (71, 109);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (71, 133);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (72, 134);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (73, 110);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (73, 135);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (74, 136);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (76, 111);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (78, 139);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (80, 114);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (80, 140);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (81, 141);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (82, 115);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (82, 142);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (83, 116);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (83, 143);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (85, 144);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (86, 117);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (86, 118);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (86, 119);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (86, 145);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (87, 120);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (87, 121);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (87, 146);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (88, 122);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (88, 123);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (88, 124);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (88, 125);


#
# TABLE STRUCTURE FOR: tbl_unidade_usuario
#

DROP TABLE IF EXISTS `tbl_unidade_usuario`;

CREATE TABLE `tbl_unidade_usuario` (
  `id_usuario` int(11) NOT NULL,
  `id_unidade` int(11) NOT NULL,
  PRIMARY KEY (`id_usuario`,`id_unidade`),
  KEY `FK_tbl_unidade_usuario_tbl_unidade` (`id_unidade`),
  KEY `FK_tbl_unidade_usuario_tbl_usuario` (`id_usuario`),
  CONSTRAINT `FK_tbl_unidade_usuario_tbl_unidade` FOREIGN KEY (`id_unidade`) REFERENCES `tbl_unidade` (`id_unidade`),
  CONSTRAINT `FK_tbl_unidade_usuario_tbl_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `tbl_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (8, 17);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (9, 7);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (9, 14);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (9, 29);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (9, 33);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (9, 38);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (9, 39);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (9, 48);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (9, 50);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (9, 54);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (9, 56);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (10, 16);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (11, 12);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (11, 25);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (11, 27);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (11, 30);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (11, 34);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (11, 44);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (11, 57);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (11, 59);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (11, 60);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (11, 65);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (12, 13);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (13, 3);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (14, 11);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (14, 21);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (14, 37);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (14, 42);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (14, 43);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (14, 45);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (14, 46);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (15, 10);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (15, 31);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (15, 53);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (15, 55);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (15, 61);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (15, 65);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (15, 79);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (16, 13);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (16, 75);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (16, 76);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (16, 77);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (16, 80);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (16, 83);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (17, 17);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (18, 17);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (19, 15);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (19, 72);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (19, 86);


#
# TABLE STRUCTURE FOR: tbl_usuario
#

DROP TABLE IF EXISTS `tbl_usuario`;

CREATE TABLE `tbl_usuario` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nome_usuario` varchar(100) NOT NULL,
  `login_usuario` varchar(100) NOT NULL,
  `email_usuario` varchar(100) NOT NULL,
  `senha_usuario` varchar(100) NOT NULL,
  `celula_equipe` varchar(100) NOT NULL,
  `status_usuario` tinyint(1) NOT NULL DEFAULT '1',
  `sobreaviso_usuario` tinyint(1) NOT NULL DEFAULT '0',
  `id_perfil` int(11) NOT NULL DEFAULT '1',
  `id_cargo` int(11) NOT NULL,
  PRIMARY KEY (`id_usuario`),
  KEY `FK_tbl_usuario_tbl_cargo` (`id_cargo`),
  KEY `FK_tbl_usuario_tbl_perfil` (`id_perfil`),
  CONSTRAINT `FK_tbl_usuario_tbl_cargo` FOREIGN KEY (`id_cargo`) REFERENCES `tbl_cargo` (`id_cargo`),
  CONSTRAINT `FK_tbl_usuario_tbl_perfil` FOREIGN KEY (`id_perfil`) REFERENCES `tbl_perfil` (`id_perfil`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (3, João Paulo de Lima Saraiva, joao.saraiva, joao.saraiva@sefa.pa.gov.br, 05admin18, CGRE-Produção, 1, 1, 1, 1);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (4, Patrese Lineker kauffmann Monteiro, patrese.monteiro, patrese.monteiro@sefa.pa.gov.br, 13062010, CGRE-Produção, 1, 0, 1, 1);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (5, Bruna dos Santos Araújo, bruna.araujo, bruna.araujo@sefa.pa.gov.br, guilherme2702, CGRE-Produção, 1, 0, 1, 1);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (6, Gilberto Cesar Azevedo Balieiro, gilberto.balieiro, gilberto.balieiro@sefa.pa.gov.br, G1511go57, CGRE-Produção, 1, 0, 1, 1);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (7, Sérgio Augusto de Souza Rebello Filho, sergio.filho, sergio.filho@sefa.pa.gov.br, sefa1111, CGRE-Produção, 1, 0, 1, 1);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (8, Adao de Abreu, adao, adao@sefa.pa.gov.br, , CGAQ-Tecnico, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (9, Wagner Brandao dos Santos, wagner, wagner@sefa.pa.gov.br, , CGAQ-Tecnico, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (10, Fernando Antonio Leite Costa, fleite, fleite@sefa.pa.gov.br, , CGAQ-Tecnico, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (11, Francisco Carvalho Cruz, fccruz, fccruz@sefa.pa.gov.br, , CGAQ-Tecnico, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (12, Antonio Carlos Botelho de Moraes, abotelho, abotelho@sefa.pa.gov.br, , CAFE, 1, 0, 1, 16);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (13, Mauricio da Silva Brasil, mbrasil, mbrasil@sefa.pa.gov.br, , CGRE - Produção, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (14, Elias de Sousa Marinho Junior, elias.junior, elias.junior@sefa.pa.gov.br, , CGAQ-Tecnico, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (15, Edilson do Nascimento Luz, edilson.luz, edilson.luz@sefa.pa.gov.br, , CGAQ-Tecnico, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (16, Waldir Junior Lobo Marques, waldir.marques, waldir.marques@sefa.pa.gov.br, , CGAQ-Tecnico, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (17, Maurecy Rodrigues Alves, maurecy.alves, maurecy.alves@sefa.pa.gov.br, , CGAQ-Tecnico, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (18, João Paulo dos Santos Monteiro, joao.monteiro, joao.monteiro@sefa.pa.gov.br, , CGAQ-Tecnico, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (19, Jean Jacques Oliveira Gomes, jean.gomes, jean.gomes@sefa.pa.gov.br, , CGAQ-Tecnico, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (20, George Fabrizio Neves Felicidade, gneves, gneves@sefa.pa.gov.br, , CGAQ-Tecnico, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (21, Bruno Falcão Leal, bruno.leal, bruno.leal@sefa.pa.gov.br, , CGAQ-Tecnico, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (22, Pedro Pastana de Oliveira Junior, ppastana, ppastana@sefa.pa.gov.br, , CGAQ-Tecnico, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (23, Juares dos Santos Machado Junior, juares.junior, juares.junior@sefa.pa.gov.br, , CGAQ-Tecnico, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (24, Thiago Oliveira dos Santos, thiago.santos, thiago.santos@sefa.pa.gov.br, , CGAQ-Tecnico, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (25, Rodrigo Ferreira Lopes, rodrigo.ferreira, rodrigo.ferreira@sefa.pa.gov.br, ferreira10, CGRE-Produção, 1, 0, 1, 1);


#
# TABLE STRUCTURE FOR: tbl_usuario_telefone
#

DROP TABLE IF EXISTS `tbl_usuario_telefone`;

CREATE TABLE `tbl_usuario_telefone` (
  `id_usuario` int(11) NOT NULL,
  `id_telefone` int(11) NOT NULL,
  PRIMARY KEY (`id_usuario`,`id_telefone`),
  KEY `FK_tbl_usuario_telefone_tbl_telefone` (`id_telefone`),
  KEY `FK_tbl_usuario_telefone_tbl_usuario` (`id_usuario`),
  CONSTRAINT `FK_tbl_usuario_telefone_tbl_telefone` FOREIGN KEY (`id_telefone`) REFERENCES `tbl_telefone` (`id_telefone`),
  CONSTRAINT `FK_tbl_usuario_telefone_tbl_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `tbl_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (3, 67);
INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (3, 68);
INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (8, 63);
INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (9, 79);
INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (9, 80);
INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (10, 65);
INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (10, 66);
INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (11, 69);
INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (11, 70);
INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (14, 74);
INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (15, 71);
INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (16, 72);
INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (18, 64);
INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (19, 77);
INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (20, 76);
INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (21, 75);
INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (23, 73);
INSERT INTO `tbl_usuario_telefone` (`id_usuario`, `id_telefone`) VALUES (24, 78);


