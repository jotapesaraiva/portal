#
# TABLE STRUCTURE FOR: tbl_cargo
#

DROP TABLE IF EXISTS `tbl_cargo`;

CREATE TABLE `tbl_cargo` (
  `id_cargo` int(11) NOT NULL AUTO_INCREMENT,
  `nome_cargo` varchar(100) NOT NULL,
  `comentario_cargo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_cargo`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (1, Analista de Suporte, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (2, Analista de Produção, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (3, Analista de Infraestrutura, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (4, Analista de Sistemas, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (5, Analista de Banco de Dados, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (6, Técnico de Informática, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (7, Trainee, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (8, Estagiário, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (9, Técnico Administrativo, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (10, Gerente, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (11, Gerente de RH, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (12, Gerente de Projeto, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (13, Coordenador(a), );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (14, Diretor(a), );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (15, Analista de Suporte Help Desk, );
INSERT INTO `tbl_cargo` (`id_cargo`, `nome_cargo`, `comentario_cargo`) VALUES (16, Servidor Público, );


#
# TABLE STRUCTURE FOR: tbl_cidade
#

DROP TABLE IF EXISTS `tbl_cidade`;

CREATE TABLE `tbl_cidade` (
  `id_cidade` int(11) NOT NULL AUTO_INCREMENT,
  `nome_cidade` varchar(100) NOT NULL,
  `comentario_cidade` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_cidade`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (1, Abaetetuba, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (2, Abel Figueiredo, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (3, Acará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (4, Afuá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (5, Água Azul do Norte, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (6, Alenquer, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (7, Almeirim, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (8, Altamira, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (9, Anajás, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (10, Ananindeua, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (11, Anapu, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (12, Augusto Corrêa, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (13, Aurora do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (14, Aveiro, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (15, Bagre, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (16, Baião, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (17, Bannach, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (18, Barcarena, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (19, Belém, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (20, Belterra, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (21, Benevides, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (22, Bom Jesus do Tocantins, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (23, Bonito, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (24, Bragança, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (25, Brasil Novo, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (26, Brejo Grande do Araguaia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (27, Breu Branco, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (28, Breves, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (29, Bujaru, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (30, Cachoeira do Arari, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (31, Cachoeira do Piriá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (32, Cametá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (33, Canaã dos Carajás, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (34, Capanema, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (35, Capitão Poço, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (36, Castanhal, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (37, Chaves, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (38, Colares, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (39, Conceição do Araguaia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (40, Concórdia do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (41, Cumaru do Norte, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (42, Curionópolis, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (43, Curralinho, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (44, Curuá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (45, Curuçá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (46, Dom Eliseu, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (47, Eldorado do Carajás, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (48, Faro, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (49, Floresta do Araguaia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (50, Garrafão do Norte, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (51, Goianésia do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (52, Gurupá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (53, Igarapé-Açu, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (54, Igarapé-Miri, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (55, Inhangapi, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (56, Ipixuna do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (57, Irituia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (58, Itaituba, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (59, Itupiranga, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (60, Jacareacanga, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (61, Jacundá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (62, Juruti, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (63, Limoeiro do Ajuru, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (64, Mãe do Rio, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (65, Magalhães Barata, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (66, Marabá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (67, Maracanã, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (68, Marapanim, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (69, Marituba, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (70, Medicilândia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (71, Melgaço, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (72, Mocajuba, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (73, Moju, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (74, Mojuí dos Campos, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (75, Monte Alegre, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (76, Muaná, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (77, Nova Esperança do Piriá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (78, Nova Ipixuna, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (79, Nova Timboteua, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (80, Novo Progresso, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (81, Novo Repartimento, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (82, Óbidos, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (83, Oeiras do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (84, Oriximiná, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (85, Ourém, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (86, Ourilândia do Norte, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (87, Pacajá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (88, Palestina do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (89, Paragominas, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (90, Parauapebas, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (91, Pau d`Arco, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (92, Peixe-Boi, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (93, Piçarra, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (94, Placas, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (95, Ponta de Pedras, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (96, Portel, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (97, Porto de Moz, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (98, Prainha, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (99, Primavera, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (100, Quatipuru, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (101, Redenção, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (102, Rio Maria, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (103, Rondon do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (104, Rurópolis, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (105, Salinópolis, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (106, Salvaterra, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (107, Santa Bárbara do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (108, Santa Cruz do Arari, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (109, Santa Izabel do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (110, Santa Luzia do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (111, Santa Maria das Barreiras, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (112, Santa Maria do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (113, Santana do Araguaia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (114, Santarém, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (115, Santarém Novo, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (116, Santo Antônio do Tauá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (117, São Caetano de Odivelas, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (118, São Domingos do Araguaia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (119, São Domingos do Capim, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (120, São Félix do Xingu, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (121, São Francisco do Pará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (122, São Geraldo do Araguaia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (123, São João da Ponta, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (124, São João de Pirabas, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (125, São João do Araguaia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (126, São Miguel do Guamá, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (127, São Sebastião da Boa Vista, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (128, Sapucaia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (129, Senador José Porfírio, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (130, Soure, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (131, Tailândia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (132, Terra Alta, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (133, Terra Santa, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (134, Tomé-Açu, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (135, Tracuateua, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (136, Trairão, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (137, Tucumã, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (138, Tucuruí, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (139, Ulianópolis, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (140, Uruará, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (141, Vigia, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (142, Viseu, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (143, Vitória do Xingu, NULL);
INSERT INTO `tbl_cidade` (`id_cidade`, `nome_cidade`, `comentario_cidade`) VALUES (144, Xinguara, NULL);


#
# TABLE STRUCTURE FOR: tbl_contato
#

DROP TABLE IF EXISTS `tbl_contato`;

CREATE TABLE `tbl_contato` (
  `id_contato` int(11) NOT NULL AUTO_INCREMENT,
  `nome_contato` varchar(100) NOT NULL,
  `email_contato` varchar(100) NOT NULL,
  `cargo_contato` varchar(100) DEFAULT NULL,
  `comentario_contato` varchar(100) DEFAULT NULL,
  `id_fornecedor` int(11) NOT NULL,
  PRIMARY KEY (`id_contato`),
  KEY `FK_tbl_contato_tbl_fornecedor` (`id_fornecedor`),
  CONSTRAINT `FK_tbl_contato_tbl_fornecedor` FOREIGN KEY (`id_fornecedor`) REFERENCES `tbl_fornecedor` (`id_fornecedor`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (1, Bárbara, , Central de Atendimento, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (2, Anderson, , Técnico, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (3, Paulo Branco, , Dados, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (4, Valdenildo, , Técnicos Externos, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (5, Fernando, , Técnicos Externos, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (6, Ana Caroline, acsanto@embratel.com.br, Central de Atendimento, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (7, Adamor Martins de Sousa, adamors@embratel.com.br, , , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (8, Jailson Viera Dantas, jailson@embratel.com.br, Unidade Corporativa, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (9, Edilson Ramos Pereira Filho, edramos@embratel.com.br, Gerente Executivo de Vendas, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (10, Domier Ferreira Cavalcante  Junior, domier@embratel.com.br, Gerente de Contas Governo, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (11, Lucineide Costa Conceição, lucost@embratel.com.br, Unidade de Mercado Empresarial, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (12, Margarete Ferreira Barbosa, marbosa@embratel.com.br, Gerência de Acesso e Ativação PA/AP/MA, , 1);
INSERT INTO `tbl_contato` (`id_contato`, `nome_contato`, `email_contato`, `cargo_contato`, `comentario_contato`, `id_fornecedor`) VALUES (13, Maria Francisca Chihomi Tanaka Owada, tanaka@embratel.com.br, Unidade de Mercado Empresarial, , 1);


#
# TABLE STRUCTURE FOR: tbl_contato_telefone
#

DROP TABLE IF EXISTS `tbl_contato_telefone`;

CREATE TABLE `tbl_contato_telefone` (
  `id_contato` int(11) NOT NULL,
  `id_telefone` int(11) NOT NULL,
  PRIMARY KEY (`id_contato`,`id_telefone`),
  KEY `FK_tbl_contato_telefone_tbl_telefone` (`id_telefone`),
  KEY `FK_tbl_contato_telefone_tbl_contato` (`id_contato`),
  CONSTRAINT `FK_tbl_contato_telefone_tbl_contato` FOREIGN KEY (`id_contato`) REFERENCES `tbl_contato` (`id_contato`),
  CONSTRAINT `FK_tbl_contato_telefone_tbl_telefone` FOREIGN KEY (`id_telefone`) REFERENCES `tbl_telefone` (`id_telefone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (1, 42);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (2, 21);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (2, 22);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (3, 23);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (3, 24);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (3, 41);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (4, 25);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (4, 26);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (5, 27);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (5, 28);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (6, 43);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (6, 44);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (7, 45);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (7, 46);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (8, 47);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (8, 48);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (9, 49);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (9, 50);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (10, 53);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (10, 54);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (11, 51);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (11, 52);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (12, 57);
INSERT INTO `tbl_contato_telefone` (`id_contato`, `id_telefone`) VALUES (13, 58);


#
# TABLE STRUCTURE FOR: tbl_expediente
#

DROP TABLE IF EXISTS `tbl_expediente`;

CREATE TABLE `tbl_expediente` (
  `id_expediente` int(11) NOT NULL AUTO_INCREMENT,
  `nome_expediente` varchar(100) NOT NULL,
  `comentario_expediente` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_expediente`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_expediente` (`id_expediente`, `nome_expediente`, `comentario_expediente`) VALUES (1, 8h - 14h, NULL);
INSERT INTO `tbl_expediente` (`id_expediente`, `nome_expediente`, `comentario_expediente`) VALUES (2, 8h - 17h, NULL);
INSERT INTO `tbl_expediente` (`id_expediente`, `nome_expediente`, `comentario_expediente`) VALUES (3, 8h - 18h, NULL);
INSERT INTO `tbl_expediente` (`id_expediente`, `nome_expediente`, `comentario_expediente`) VALUES (4, 24hs, );


#
# TABLE STRUCTURE FOR: tbl_fornecedor
#

DROP TABLE IF EXISTS `tbl_fornecedor`;

CREATE TABLE `tbl_fornecedor` (
  `id_fornecedor` int(11) NOT NULL AUTO_INCREMENT,
  `nome_fornecedor` varchar(100) NOT NULL,
  `website_fornecedor` varchar(100) DEFAULT NULL,
  `email_fornecedor` varchar(100) DEFAULT NULL,
  `endereco_fornecedor` varchar(100) DEFAULT NULL,
  `comentario_fornecedor` varchar(100) DEFAULT NULL,
  `status_fornecedor` tinyint(1) NOT NULL DEFAULT '1',
  `id_servico` int(11) NOT NULL,
  PRIMARY KEY (`id_fornecedor`),
  KEY `FK_tbl_fornecedor_tbl_servico` (`id_servico`),
  CONSTRAINT `FK_tbl_fornecedor_tbl_servico` FOREIGN KEY (`id_servico`) REFERENCES `tbl_servico` (`id_servico`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_fornecedor` (`id_fornecedor`, `nome_fornecedor`, `website_fornecedor`, `email_fornecedor`, `endereco_fornecedor`, `comentario_fornecedor`, `status_fornecedor`, `id_servico`) VALUES (1, Embratel, http://www.embratel.com.br/embratelonline, , , , 1, 1);
INSERT INTO `tbl_fornecedor` (`id_fornecedor`, `nome_fornecedor`, `website_fornecedor`, `email_fornecedor`, `endereco_fornecedor`, `comentario_fornecedor`, `status_fornecedor`, `id_servico`) VALUES (2, PRODEPA, http://www.prodepa.pa.gov.br/, cap@prodepa.pa.gov.br, Av. Agusto Montenegro, s/n, , 1, 1);


#
# TABLE STRUCTURE FOR: tbl_fornecedor_telefone
#

DROP TABLE IF EXISTS `tbl_fornecedor_telefone`;

CREATE TABLE `tbl_fornecedor_telefone` (
  `id_fornecedor` int(11) NOT NULL,
  `id_telefone` int(11) NOT NULL,
  PRIMARY KEY (`id_fornecedor`,`id_telefone`),
  KEY `FK_tbl_fornecedor_telefone_tbl_telefone` (`id_telefone`),
  KEY `FK_tbl_fornecedor_telefone_tbl_fornecedor` (`id_fornecedor`),
  CONSTRAINT `FK_tbl_fornecedor_telefone_tbl_fornecedor` FOREIGN KEY (`id_fornecedor`) REFERENCES `tbl_fornecedor` (`id_fornecedor`),
  CONSTRAINT `FK_tbl_fornecedor_telefone_tbl_telefone` FOREIGN KEY (`id_telefone`) REFERENCES `tbl_telefone` (`id_telefone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_link
#

DROP TABLE IF EXISTS `tbl_link`;

CREATE TABLE `tbl_link` (
  `id_link` int(11) NOT NULL AUTO_INCREMENT,
  `nome_link` varchar(100) NOT NULL,
  `designacao_link` varchar(100) NOT NULL,
  `ip_lan_link` varchar(100) NOT NULL,
  `ip_wan_link` varchar(100) NOT NULL,
  `status_link` tinyint(1) NOT NULL DEFAULT '0',
  `backup_link` tinyint(1) NOT NULL DEFAULT '0',
  `id_tipo_velocidade` int(11) NOT NULL,
  `id_tipo_acesso` int(11) NOT NULL,
  `id_unidade` int(11) NOT NULL,
  `id_fornecedor` int(11) NOT NULL,
  PRIMARY KEY (`id_link`),
  KEY `FK_tbl_link_tbl_tipo_velocidade` (`id_tipo_velocidade`),
  KEY `FK_tbl_link_tbl_tipo_acesso` (`id_tipo_acesso`),
  KEY `FK_tbl_link_tbl_unidade` (`id_unidade`),
  KEY `FK_tbl_link_tbl_fornecedor` (`id_fornecedor`),
  CONSTRAINT `FK_tbl_link_tbl_fornecedor` FOREIGN KEY (`id_fornecedor`) REFERENCES `tbl_fornecedor` (`id_fornecedor`),
  CONSTRAINT `FK_tbl_link_tbl_tipo_acesso` FOREIGN KEY (`id_tipo_acesso`) REFERENCES `tbl_tipo_acesso` (`id_tipo_acesso`),
  CONSTRAINT `FK_tbl_link_tbl_tipo_velocidade` FOREIGN KEY (`id_tipo_velocidade`) REFERENCES `tbl_tipo_velocidade` (`id_tipo_velocidade`),
  CONSTRAINT `FK_tbl_link_tbl_unidade` FOREIGN KEY (`id_unidade`) REFERENCES `tbl_unidade` (`id_unidade`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (1, mba_cecomt_mba, MBA/IP/00615, 10.2.204.10, 200.208.16.38, 1, 0, 5, 6, 14, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (2, chia_cecomt_chia, CHIA/IP/00103, 10.2.150.2, 189.2.78.178, 1, 0, 4, 6, 16, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (3, chia_cecomt_gurupi_b, CHIA/IP/00104, 10.2.150.3, 201.56.182.62, 1, 1, 3, 6, 16, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (4, bcn_oeat_bcn, BCN/IP/00300, 10.2.61.10, 201.31.147.222, 1, 0, 5, 6, 24, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (5, cpc_oeat_cpc, CPC/IP/00104, 10.2.85.10, 201.90.230.10, 1, 0, 2, 3, 28, 1);
INSERT INTO `tbl_link` (`id_link`, `nome_link`, `designacao_link`, `ip_lan_link`, `ip_wan_link`, `status_link`, `backup_link`, `id_tipo_velocidade`, `id_tipo_acesso`, `id_unidade`, `id_fornecedor`) VALUES (6, cme_oeat_cme, CME/IP/00108, 10.2.62.10, 201.31.147.50, 1, 0, 3, 6, 26, 1);


#
# TABLE STRUCTURE FOR: tbl_perfil
#

DROP TABLE IF EXISTS `tbl_perfil`;

CREATE TABLE `tbl_perfil` (
  `id_perfil` int(11) NOT NULL AUTO_INCREMENT,
  `nome_perfil` varchar(100) NOT NULL,
  `comentario_perfil` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_perfil`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_perfil` (`id_perfil`, `nome_perfil`, `comentario_perfil`) VALUES (1, Usuario Comum, NULL);
INSERT INTO `tbl_perfil` (`id_perfil`, `nome_perfil`, `comentario_perfil`) VALUES (2, Administrador, NULL);
INSERT INTO `tbl_perfil` (`id_perfil`, `nome_perfil`, `comentario_perfil`) VALUES (3, Super Admin, NULL);


#
# TABLE STRUCTURE FOR: tbl_servico
#

DROP TABLE IF EXISTS `tbl_servico`;

CREATE TABLE `tbl_servico` (
  `id_servico` int(11) NOT NULL AUTO_INCREMENT,
  `nome_servico` varchar(100) NOT NULL,
  `comentario_servico` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_servico`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_servico` (`id_servico`, `nome_servico`, `comentario_servico`) VALUES (1, Link de Dados, NULL);
INSERT INTO `tbl_servico` (`id_servico`, `nome_servico`, `comentario_servico`) VALUES (2, Roteador /  Switchs, NULL);
INSERT INTO `tbl_servico` (`id_servico`, `nome_servico`, `comentario_servico`) VALUES (3, Servidores / Storage /Library, NULL);
INSERT INTO `tbl_servico` (`id_servico`, `nome_servico`, `comentario_servico`) VALUES (4, Nobreak / Gerador, NULL);
INSERT INTO `tbl_servico` (`id_servico`, `nome_servico`, `comentario_servico`) VALUES (5, Central de ar, NULL);
INSERT INTO `tbl_servico` (`id_servico`, `nome_servico`, `comentario_servico`) VALUES (6, Software, NULL);


#
# TABLE STRUCTURE FOR: tbl_telefone
#

DROP TABLE IF EXISTS `tbl_telefone`;

CREATE TABLE `tbl_telefone` (
  `id_telefone` int(11) NOT NULL AUTO_INCREMENT,
  `numero_telefone` varchar(30) NOT NULL,
  `id_tipo_categoria_telefone` int(11) NOT NULL,
  PRIMARY KEY (`id_telefone`),
  UNIQUE KEY `numero_telefone` (`numero_telefone`),
  KEY `FK_tbl_telefone_tbl_tipo_categoria_telefone` (`id_tipo_categoria_telefone`),
  CONSTRAINT `FK_tbl_telefone_tbl_tipo_categoria_telefone` FOREIGN KEY (`id_tipo_categoria_telefone`) REFERENCES `tbl_tipo_categoria_telefone` (`id_tipo_categoria_telefone`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (1, (91) 3323-4477, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (2, (91) 3323-3599, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (3, (91) 3323-4448, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (4, (91) 3323-3884, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (5, (91) 3323-4480, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (6, (91) 3323-3853, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (7, (91) 3323-4483, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (8, (91) 3323-4473, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (9, (91) 3323-3871, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (10, (91) 3323-4476, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (11, (91) 3323-4475, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (12, (91) 3323-4482, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (13, (91) 3323-3873, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (14, (91) 3323-3870, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (15, (91) 3323-3872, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (16, (91) 9882-9610, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (17, (91) 3323-4333, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (18, (91) 3323-3859, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (19, (91) 3323-3860, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (20, (91) 3323-4439, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (21, (91) 4005-8145, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (22, (91) 98418-0579, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (23, (91) 4005-8118, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (24, (91) 98405-4591, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (25, (94) 2101-9991, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (26, (94) 98409-9910, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (27, (91) 3235-5201, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (28, (91) 98425-3750, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (29, (91) 3323-4472, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (30, (91) 3323-4498, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (31, (91) 3323-4433, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (32, (91) 3323-4429, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (33, (91) 3323-3877, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (34, (91) 3323-3876, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (35, (91) 3323-3890, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (36, (91) 3323-3875, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (37, (91) 3323-4412, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (38, (91) 3323-4408, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (39, (91) 3323-4402, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (40, (91) 3323-4492, 4);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (41, (91) 3323-4994, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (42, (31) 2121-3840, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (43, (31) 2121-3846, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (44, (31) 2121-3710, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (45, (91) 4005-8172, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (46, (91) 98436-3255, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (47, (61) 2106-8228, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (48, (61) 99272-3224, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (49, (91) 4005-8114, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (50, (91) 98412-3323, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (51, (91) 4005-8442, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (52, (91) 98441-2329, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (53, (91) 4005-8254, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (54, (91) 98467-8335, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (57, (91) 4005-8451, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (58, (91) 4005-8214, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (59, (91) 3184-4609, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (60, (91) 3184-4600, 1);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (61, (91) 98256-2958, 2);
INSERT INTO `tbl_telefone` (`id_telefone`, `numero_telefone`, `id_tipo_categoria_telefone`) VALUES (62, (91) 3323-4400, 4);


#
# TABLE STRUCTURE FOR: tbl_telefone_voip
#

DROP TABLE IF EXISTS `tbl_telefone_voip`;

CREATE TABLE `tbl_telefone_voip` (
  `id_telefone_voip` int(11) NOT NULL AUTO_INCREMENT,
  `ip_telefone_voip` varchar(15) NOT NULL,
  `descricao_telefone_voip` varchar(100) NOT NULL,
  `id_telefone` int(11) NOT NULL,
  `id_tipo_categoria_voip` int(11) NOT NULL,
  `id_tipo_equipamento_voip` int(11) NOT NULL,
  `id_tipo_contexto_voip` int(11) NOT NULL,
  PRIMARY KEY (`id_telefone_voip`),
  UNIQUE KEY `id_telefone` (`id_telefone`),
  KEY `id_tipo_categoria` (`id_tipo_categoria_voip`),
  KEY `id_tipo_equipamento` (`id_tipo_equipamento_voip`),
  KEY `id_tipo_contexto` (`id_tipo_contexto_voip`),
  CONSTRAINT `FK_tbl_telefone_voip_tbl_telefone` FOREIGN KEY (`id_telefone`) REFERENCES `tbl_telefone` (`id_telefone`),
  CONSTRAINT `FK_tbl_telefone_voip_tbl_tipo_categoria_voip` FOREIGN KEY (`id_tipo_categoria_voip`) REFERENCES `tbl_tipo_categoria_voip` (`id_tipo_categoria_voip`),
  CONSTRAINT `FK_tbl_telefone_voip_tbl_tipo_contexto_voip` FOREIGN KEY (`id_tipo_contexto_voip`) REFERENCES `tbl_tipo_contexto_voip` (`id_tipo_contexto_voip`),
  CONSTRAINT `FK_tbl_telefone_voip_tbl_tipo_equipamento_voip` FOREIGN KEY (`id_tipo_equipamento_voip`) REFERENCES `tbl_tipo_equipamento_voip` (`id_tipo_equipamento_voip`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (1, 10.2.60.107, , 1, 2, 2, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (2, , , 2, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (3, 10.2.204.100, , 3, 2, 2, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (4, , , 4, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (5, 10.2.200.180, Fiscalização, 5, 2, 2, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (6, , , 6, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (7, 10.2.150.102, , 7, 2, 1, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (8, 10.2.150.102, , 8, 2, 1, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (9, , , 9, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (10, 10.2.17.101, , 10, 2, 2, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (11, 10.2.17.106, , 11, 2, 1, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (12, 10.2.17.106, , 12, 2, 1, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (13, , , 13, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (14, , , 14, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (15, , , 15, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (16, , , 16, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (17, , , 17, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (18, , , 18, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (19, 10.2.60.10, , 19, 2, 3, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (20, , , 20, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (21, 10.2.100.43, , 29, 2, 2, 5);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (22, , , 30, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (23, , , 31, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (24, , , 32, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (25, , , 33, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (26, , , 34, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (27, , , 35, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (28, , , 36, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (29, , , 37, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (30, , , 38, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (31, , , 39, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (32, , , 40, 1, 3, 7);
INSERT INTO `tbl_telefone_voip` (`id_telefone_voip`, `ip_telefone_voip`, `descricao_telefone_voip`, `id_telefone`, `id_tipo_categoria_voip`, `id_tipo_equipamento_voip`, `id_tipo_contexto_voip`) VALUES (33, 10.2.147.10, , 62, 1, 3, 7);


#
# TABLE STRUCTURE FOR: tbl_tipo_acesso
#

DROP TABLE IF EXISTS `tbl_tipo_acesso`;

CREATE TABLE `tbl_tipo_acesso` (
  `id_tipo_acesso` int(11) NOT NULL AUTO_INCREMENT,
  `nome_tipo_acesso` varchar(100) NOT NULL,
  `comentario_tipo_acesso` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_tipo_acesso`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_tipo_acesso` (`id_tipo_acesso`, `nome_tipo_acesso`, `comentario_tipo_acesso`) VALUES (1, Rádio, NULL);
INSERT INTO `tbl_tipo_acesso` (`id_tipo_acesso`, `nome_tipo_acesso`, `comentario_tipo_acesso`) VALUES (2, Satélite, NULL);
INSERT INTO `tbl_tipo_acesso` (`id_tipo_acesso`, `nome_tipo_acesso`, `comentario_tipo_acesso`) VALUES (3, Fibra Óptica, );
INSERT INTO `tbl_tipo_acesso` (`id_tipo_acesso`, `nome_tipo_acesso`, `comentario_tipo_acesso`) VALUES (4, Dial modem, );
INSERT INTO `tbl_tipo_acesso` (`id_tipo_acesso`, `nome_tipo_acesso`, `comentario_tipo_acesso`) VALUES (5, XDSL, );
INSERT INTO `tbl_tipo_acesso` (`id_tipo_acesso`, `nome_tipo_acesso`, `comentario_tipo_acesso`) VALUES (6, Cabo, );


#
# TABLE STRUCTURE FOR: tbl_tipo_categoria_telefone
#

DROP TABLE IF EXISTS `tbl_tipo_categoria_telefone`;

CREATE TABLE `tbl_tipo_categoria_telefone` (
  `id_tipo_categoria_telefone` int(11) NOT NULL AUTO_INCREMENT,
  `nome_tipo_categoria_telefone` varchar(100) NOT NULL,
  `comentario_tipo_categoria_telefone` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_tipo_categoria_telefone`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_tipo_categoria_telefone` (`id_tipo_categoria_telefone`, `nome_tipo_categoria_telefone`, `comentario_tipo_categoria_telefone`) VALUES (1, Fixo, NULL);
INSERT INTO `tbl_tipo_categoria_telefone` (`id_tipo_categoria_telefone`, `nome_tipo_categoria_telefone`, `comentario_tipo_categoria_telefone`) VALUES (2, Celular, NULL);
INSERT INTO `tbl_tipo_categoria_telefone` (`id_tipo_categoria_telefone`, `nome_tipo_categoria_telefone`, `comentario_tipo_categoria_telefone`) VALUES (3, Ramal, NULL);
INSERT INTO `tbl_tipo_categoria_telefone` (`id_tipo_categoria_telefone`, `nome_tipo_categoria_telefone`, `comentario_tipo_categoria_telefone`) VALUES (4, Voip, NULL);


#
# TABLE STRUCTURE FOR: tbl_tipo_categoria_voip
#

DROP TABLE IF EXISTS `tbl_tipo_categoria_voip`;

CREATE TABLE `tbl_tipo_categoria_voip` (
  `id_tipo_categoria_voip` int(11) NOT NULL AUTO_INCREMENT,
  `nome_tipo_categoria_voip` varchar(100) NOT NULL,
  `comentario_tipo_categoria_voip` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_tipo_categoria_voip`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_tipo_categoria_voip` (`id_tipo_categoria_voip`, `nome_tipo_categoria_voip`, `comentario_tipo_categoria_voip`) VALUES (1, FXS, NULL);
INSERT INTO `tbl_tipo_categoria_voip` (`id_tipo_categoria_voip`, `nome_tipo_categoria_voip`, `comentario_tipo_categoria_voip`) VALUES (2, SIP, NULL);
INSERT INTO `tbl_tipo_categoria_voip` (`id_tipo_categoria_voip`, `nome_tipo_categoria_voip`, `comentario_tipo_categoria_voip`) VALUES (3, New Bridge, NULL);
INSERT INTO `tbl_tipo_categoria_voip` (`id_tipo_categoria_voip`, `nome_tipo_categoria_voip`, `comentario_tipo_categoria_voip`) VALUES (4, teste, TESTE);
INSERT INTO `tbl_tipo_categoria_voip` (`id_tipo_categoria_voip`, `nome_tipo_categoria_voip`, `comentario_tipo_categoria_voip`) VALUES (6, nova categoria, teste);


#
# TABLE STRUCTURE FOR: tbl_tipo_contexto_voip
#

DROP TABLE IF EXISTS `tbl_tipo_contexto_voip`;

CREATE TABLE `tbl_tipo_contexto_voip` (
  `id_tipo_contexto_voip` int(11) NOT NULL AUTO_INCREMENT,
  `nome_tipo_contexto_voip` varchar(100) NOT NULL,
  `comentario_tipo_contexto_voip` varchar(100) NOT NULL,
  PRIMARY KEY (`id_tipo_contexto_voip`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_tipo_contexto_voip` (`id_tipo_contexto_voip`, `nome_tipo_contexto_voip`, `comentario_tipo_contexto_voip`) VALUES (1, Acesso Padrão, );
INSERT INTO `tbl_tipo_contexto_voip` (`id_tipo_contexto_voip`, `nome_tipo_contexto_voip`, `comentario_tipo_contexto_voip`) VALUES (2, Acesso Local Fixo, );
INSERT INTO `tbl_tipo_contexto_voip` (`id_tipo_contexto_voip`, `nome_tipo_contexto_voip`, `comentario_tipo_contexto_voip`) VALUES (3, Acesso Local Celular, );
INSERT INTO `tbl_tipo_contexto_voip` (`id_tipo_contexto_voip`, `nome_tipo_contexto_voip`, `comentario_tipo_contexto_voip`) VALUES (4, Acesso Fixo PA, );
INSERT INTO `tbl_tipo_contexto_voip` (`id_tipo_contexto_voip`, `nome_tipo_contexto_voip`, `comentario_tipo_contexto_voip`) VALUES (5, Acesso DDD Fixo, );
INSERT INTO `tbl_tipo_contexto_voip` (`id_tipo_contexto_voip`, `nome_tipo_contexto_voip`, `comentario_tipo_contexto_voip`) VALUES (6, Acesso DDD Celular, );
INSERT INTO `tbl_tipo_contexto_voip` (`id_tipo_contexto_voip`, `nome_tipo_contexto_voip`, `comentario_tipo_contexto_voip`) VALUES (7, Acesso Total, );


#
# TABLE STRUCTURE FOR: tbl_tipo_equipamento_voip
#

DROP TABLE IF EXISTS `tbl_tipo_equipamento_voip`;

CREATE TABLE `tbl_tipo_equipamento_voip` (
  `id_tipo_equipamento_voip` int(11) NOT NULL AUTO_INCREMENT,
  `nome_tipo_equipamento_voip` varchar(100) NOT NULL,
  `comentario_tipo_equipamento_voip` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_tipo_equipamento_voip`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_tipo_equipamento_voip` (`id_tipo_equipamento_voip`, `nome_tipo_equipamento_voip`, `comentario_tipo_equipamento_voip`) VALUES (1, ATA - Linksys, );
INSERT INTO `tbl_tipo_equipamento_voip` (`id_tipo_equipamento_voip`, `nome_tipo_equipamento_voip`, `comentario_tipo_equipamento_voip`) VALUES (2, Telefone IP, NULL);
INSERT INTO `tbl_tipo_equipamento_voip` (`id_tipo_equipamento_voip`, `nome_tipo_equipamento_voip`, `comentario_tipo_equipamento_voip`) VALUES (3, Telefone Analógico, NULL);


#
# TABLE STRUCTURE FOR: tbl_tipo_velocidade
#

DROP TABLE IF EXISTS `tbl_tipo_velocidade`;

CREATE TABLE `tbl_tipo_velocidade` (
  `id_tipo_velocidade` int(11) NOT NULL AUTO_INCREMENT,
  `nome_tipo_velocidade` varchar(100) NOT NULL,
  `comentario_tipo_velocidade` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_tipo_velocidade`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (1, 64, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (2, 128, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (3, 256, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (4, 512, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (5, 1024, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (6, 2048, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (7, 4096, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (8, 8192, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (9, 16384, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (10, 2048, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (11, 384, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (12, 6144, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (13, 10240, NULL);
INSERT INTO `tbl_tipo_velocidade` (`id_tipo_velocidade`, `nome_tipo_velocidade`, `comentario_tipo_velocidade`) VALUES (14, 34816, NULL);


#
# TABLE STRUCTURE FOR: tbl_unidade
#

DROP TABLE IF EXISTS `tbl_unidade`;

CREATE TABLE `tbl_unidade` (
  `id_unidade` int(11) NOT NULL AUTO_INCREMENT,
  `nome_unidade` varchar(100) NOT NULL,
  `endereco_unidade` varchar(100) NOT NULL,
  `status_unidade` tinyint(1) NOT NULL DEFAULT '1',
  `comentario_unidade` varchar(100) DEFAULT NULL,
  `id_unidade_responsavel` int(11) DEFAULT NULL,
  `id_cidade` int(11) NOT NULL,
  `id_expediente` int(11) NOT NULL,
  PRIMARY KEY (`id_unidade`),
  KEY `FK_tbl_unidade_tbl_cidade` (`id_cidade`),
  KEY `FK_tbl_unidade_tbl_expediente` (`id_expediente`),
  KEY `FK_tbl_unidade_tbl_unidade` (`id_unidade_responsavel`),
  CONSTRAINT `FK_tbl_unidade_tbl_cidade` FOREIGN KEY (`id_cidade`) REFERENCES `tbl_cidade` (`id_cidade`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_tbl_unidade_tbl_expediente` FOREIGN KEY (`id_expediente`) REFERENCES `tbl_expediente` (`id_expediente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_tbl_unidade_tbl_unidade` FOREIGN KEY (`id_unidade_responsavel`) REFERENCES `tbl_unidade` (`id_unidade`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (1, CERAT Abaetetuba, Av. Pedro Rodrigues, 140 - Centro., 1, , NULL, 1, 2);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (2, CERAT Altamira, Rua Otaviano Santos 2296, 1, NULL, NULL, 8, 2);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (3, CERAT Belém, Av. Gentil Bittencurt 256, São Braz, 1, , NULL, 19, 3);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (4, CERAT Breves, Rua Dra. Wilson Frazão, 348, 1, , NULL, 28, 3);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (5, CERAT Capanema, End.: Rua João Pessoa, 109, centro, 1, , NULL, 34, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (6, CERAT Castanhal, Rua Paes de Carvalho 1128-Centro, 1, , NULL, 36, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (7, CERAT Marabá, Rod. Transamazônica, km 05, 1, , NULL, 66, 2);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (8, CERAT Marituba, Rod. BR 316 s/n km 13 - ao lado da prefeitura de Marituba, em frente ao Jotão, 1, , NULL, 69, 2);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (9, CERAT Paragominas, Av. Presidente Vargas s/n - Próximo ao Hospital Municipal, 1, , NULL, 89, 2);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (10, CERAT Redenção, Av. Marechal Rondon, 855 Núcleo Urbano, 1, , NULL, 101, 2);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (11, CERAT Santarém, AV. Mendonça Furtado, 2797 - Fátima, 1, , NULL, 114, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (12, CERAT Tucurui, Av. Aluísio Chaves 155, esquina com a Av. Fernando Guilhon, Nova Tucuruí, 1, , NULL, 138, 2);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (13, CECOMT Belém, Trav João Balbi, Nº 207, 1, , NULL, 19, 2);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (14, CECOMT Carajás, Rod -. Transamazônica, Km 9 Marabá, 1, , NULL, 66, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (15, CECOMT Conceição do Araguaia , Rodovia Pa-447 Km 15, 1, , NULL, 39, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (16, CECOMT Gurupi, Rod. BR-316, Km 280, 1, , NULL, 31, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (17, CECOMT Itinga , Rod. BR 010 km 1481 -Fronteira Pará/Maranhão Vila Bela Vista , 1, , NULL, 46, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (18, CECOMT Portos e Aeroportos , Av. D. Pedro I 1097, 1, , NULL, 19, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (19, CECOMT Serra do Cachimbo , BR 63 Santarém Cuiabá km 970, 1, , NULL, 80, 4);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (20, OEAT Afuá, Rua Mariano Cândido S/N., 1, , 4, 4, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (21, OEAT Almerim, Rua Amândido Pantoja S/N, 1, , 11, 7, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (22, OEAT Ananindeua, Rod. Br 316 Km 05, 1, , 8, 10, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (23, OEAT Barcarena, Av. Cronge da Silveira 488  Centro., 1, , 1, 18, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (24, OEAT Bragança, Av. Marechal Floriano Peixoto, S/N, 1, , 5, 24, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (25, OEAT Breu Branco, Rod Pa, 263, Km 12, 1, , 12, 27, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (26, OEAT Cametá, Praça Deodoro da Fonseca, 485, 1, , 1, 32, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (27, OEAT Canaã dos Carajás, Rua, 0, , 7, 66, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (28, OEAT Capitão Poço, Av. 29 de Dezembro s/n, centro, 1, , 9, 35, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (29, OEAT Cidade Nova Marabá, Rua Frei Raimundo Lambezart, 1814, 1, , 7, 66, 1);
INSERT INTO `tbl_unidade` (`id_unidade`, `nome_unidade`, `endereco_unidade`, `status_unidade`, `comentario_unidade`, `id_unidade_responsavel`, `id_cidade`, `id_expediente`) VALUES (30, UECOMT São Francisco, BR 316, s/n - km 82 - Município de São Francisco, 1, , 13, 121, 4);


#
# TABLE STRUCTURE FOR: tbl_unidade_telefone
#

DROP TABLE IF EXISTS `tbl_unidade_telefone`;

CREATE TABLE `tbl_unidade_telefone` (
  `id_unidade` int(11) NOT NULL,
  `id_telefone` int(11) NOT NULL,
  PRIMARY KEY (`id_unidade`,`id_telefone`),
  KEY `FK_tbl_unidade_telefone_tbl_telefone_idx` (`id_telefone`),
  KEY `FK_tbl_unidade_telefone_tbl_unidade_idx` (`id_unidade`),
  CONSTRAINT `FK_tbl_unidade_telefone_tbl_telefone` FOREIGN KEY (`id_telefone`) REFERENCES `tbl_telefone` (`id_telefone`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_tbl_unidade_telefone_tbl_unidade` FOREIGN KEY (`id_unidade`) REFERENCES `tbl_unidade` (`id_unidade`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (1, 1);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (1, 19);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (2, 20);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (2, 29);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (3, 30);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (4, 31);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (6, 32);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (8, 33);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (8, 34);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (8, 35);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (8, 36);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (9, 37);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (10, 38);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (10, 39);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (12, 40);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (13, 2);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (13, 59);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (13, 60);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (14, 3);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (14, 4);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (15, 5);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (15, 6);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (16, 7);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (16, 8);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (17, 9);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (17, 10);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (17, 11);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (17, 12);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (18, 13);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (18, 14);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (18, 15);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (18, 16);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (19, 17);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (19, 18);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (30, 61);
INSERT INTO `tbl_unidade_telefone` (`id_unidade`, `id_telefone`) VALUES (30, 62);


#
# TABLE STRUCTURE FOR: tbl_unidade_usuario
#

DROP TABLE IF EXISTS `tbl_unidade_usuario`;

CREATE TABLE `tbl_unidade_usuario` (
  `id_usuario` int(11) NOT NULL,
  `id_unidade` int(11) NOT NULL,
  PRIMARY KEY (`id_usuario`,`id_unidade`),
  KEY `FK_tbl_unidade_usuario_tbl_unidade` (`id_unidade`),
  KEY `FK_tbl_unidade_usuario_tbl_usuario` (`id_usuario`),
  CONSTRAINT `FK_tbl_unidade_usuario_tbl_unidade` FOREIGN KEY (`id_unidade`) REFERENCES `tbl_unidade` (`id_unidade`),
  CONSTRAINT `FK_tbl_unidade_usuario_tbl_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `tbl_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (8, 17);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (9, 14);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (10, 16);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (11, 12);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (11, 25);
INSERT INTO `tbl_unidade_usuario` (`id_usuario`, `id_unidade`) VALUES (12, 13);


#
# TABLE STRUCTURE FOR: tbl_usuario
#

DROP TABLE IF EXISTS `tbl_usuario`;

CREATE TABLE `tbl_usuario` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nome_usuario` varchar(100) NOT NULL,
  `login_usuario` varchar(100) NOT NULL,
  `email_usuario` varchar(100) NOT NULL,
  `senha_usuario` varchar(100) NOT NULL,
  `celula_equipe` varchar(100) NOT NULL,
  `status_usuario` tinyint(1) NOT NULL DEFAULT '1',
  `sobreaviso_usuario` tinyint(1) NOT NULL DEFAULT '0',
  `id_perfil` int(11) NOT NULL DEFAULT '1',
  `id_cargo` int(11) NOT NULL,
  PRIMARY KEY (`id_usuario`),
  KEY `FK_tbl_usuario_tbl_cargo` (`id_cargo`),
  KEY `FK_tbl_usuario_tbl_perfil` (`id_perfil`),
  CONSTRAINT `FK_tbl_usuario_tbl_cargo` FOREIGN KEY (`id_cargo`) REFERENCES `tbl_cargo` (`id_cargo`),
  CONSTRAINT `FK_tbl_usuario_tbl_perfil` FOREIGN KEY (`id_perfil`) REFERENCES `tbl_perfil` (`id_perfil`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (3, João Paulo de Lima Saraiva, joao.saraiva, joao.saraiva@sefa.pa.gov.br, 04admin18, CGRE-Produção, 1, 1, 1, 1);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (4, Patrese Lineker kauffmann Monteiro, patrese.monteiro, patrese.monteiro@sefa.pa.gov.br, patrese13, CGRE-Produção, 1, 0, 1, 1);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (5, Bruna dos Santos Araújo, bruna.araujo, bruna.araujo@sefa.pa.gov.br, guilherme2702, CGRE-Produção, 1, 0, 1, 1);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (6, Gilberto Cesar Azevedo Balieiro, gilberto.balieiro, gilberto.balieiro@sefa.pa.gov.br, Go57g1511, CGRE-Produção, 1, 0, 1, 1);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (7, Sérgio Augusto de Souza Rebello Filho, sergio.filho, sergio.filho@sefa.pa.gov.br, sefa1111, CGRE-Produção, 1, 0, 1, 1);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (8, Adao de Abreu, adao, adao@sefa.pa.gov.br, , , 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (9, Wagner Brandao dos Santos, wagner, wagner@sefa.pa.gov.br, , , 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (10, Fernando Antonio Leite Costa, fleite, fleite@sefa.pa.gov.br, , CGAQ - Manutenção, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (11, Francisco Carvalho Cruz, fccruz, fccruz@sefa.pa.gov.br, , CGAQ - Manutenção, 1, 0, 1, 6);
INSERT INTO `tbl_usuario` (`id_usuario`, `nome_usuario`, `login_usuario`, `email_usuario`, `senha_usuario`, `celula_equipe`, `status_usuario`, `sobreaviso_usuario`, `id_perfil`, `id_cargo`) VALUES (12, Antonio Carlos Botelho de Moraes, abotelho, abotelho@sefa.pa.gov.br, , CAFE, 1, 0, 1, 16);


#
# TABLE STRUCTURE FOR: tbl_usuario_telefone
#

DROP TABLE IF EXISTS `tbl_usuario_telefone`;

CREATE TABLE `tbl_usuario_telefone` (
  `id_usuario` int(11) NOT NULL,
  `id_telefone` int(11) NOT NULL,
  PRIMARY KEY (`id_usuario`,`id_telefone`),
  KEY `FK_tbl_usuario_telefone_tbl_telefone` (`id_telefone`),
  KEY `FK_tbl_usuario_telefone_tbl_usuario` (`id_usuario`),
  CONSTRAINT `FK_tbl_usuario_telefone_tbl_telefone` FOREIGN KEY (`id_telefone`) REFERENCES `tbl_telefone` (`id_telefone`),
  CONSTRAINT `FK_tbl_usuario_telefone_tbl_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `tbl_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

